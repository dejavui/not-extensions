
	KeiyoushiKEI@9add655a78e96c4ec7a53ef89dccb557cb5d767489fac5e785d671a5a75d4da2"<
https://keiyoushi.github.iohttps://discord.gg/3FbCpdKbdY���
�
AHottie)eu.kanade.tachiyomi.extension.all.ahottie�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ahottie-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ahottie.png"1.4(21.4.38B-�����WAHottieall"https://ahottie.top
�
Akuma'eu.kanade.tachiyomi.extension.all.akuma�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.akuma-v1.4.10.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.akuma.png"1.4(
21.4.108B)��������Akumaall"https://akuma.moeB(�����vAkumaen"https://akuma.moeB(���Ȋ���Akumaid"https://akuma.moeB(�蘫����5Akumajv"https://akuma.moeB(���ጆ��Akumaca"https://akuma.moeB)��ȿ����EAkumaceb"https://akuma.moeB(�䲾����7Akumacs"https://akuma.moeB(�ڦ���̍SAkumada"https://akuma.moeB(����팍�vAkumade"https://akuma.moeB(�������qAkumaet"https://akuma.moeB(�܊��JAkumaes"https://akuma.moeB(���񲃮�Akumaeo"https://akuma.moeB(����櫭�Akumafr"https://akuma.moeB(��ӡ���FAkumait"https://akuma.moeB(��������Akumahi"https://akuma.moeB(��㆏��Akumahu"https://akuma.moeB(�������MAkumanl"https://akuma.moeB(���ȓ��qAkumapl"https://akuma.moeB(��ѳ����HAkumapt"https://akuma.moeB(���ٵ�Akumavi"https://akuma.moeB(������&Akumatr"https://akuma.moeB(����Ѕ�aAkumaru"https://akuma.moeB(��������HAkumauk"https://akuma.moeB(����ދ�wAkumaar"https://akuma.moeB(��������sAkumako"https://akuma.moeB(�����ک�hAkumazh"https://akuma.moeB(�����ɚ�IAkumaja"https://akuma.moe
�
AllPornComics.co1eu.kanade.tachiyomi.extension.all.allporncomicsco�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.allporncomicsco-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.allporncomicsco.png"1.4(321.4.518B;�����˨�XAllPornComics.coall"https://allporncomics.co
�
	AsmHentai+eu.kanade.tachiyomi.extension.all.asmhentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.asmhentai-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.asmhentai.png"1.4(21.4.118B0�ڌ��˫�U	AsmHentaien"https://asmhentai.comB0��譫���k	AsmHentaija"https://asmhentai.comB0񨔴Ѻ��'	AsmHentaizh"https://asmhentai.comB1��֍��Ӈl	AsmHentaiall"https://asmhentai.com
�
BaoBua(eu.kanade.tachiyomi.extension.all.baobua�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.baobua-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.baobua.png"1.4(21.4.68B+��ܰ�BaoBuaall"https://baobua.net
�
3600000 Beauty/eu.kanade.tachiyomi.extension.all.beauty3600000�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.beauty3600000-v1.4.6.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.beauty3600000.png"1.4(21.4.68B4������ɦL3600000 Beautyall"https://3600000.xyz
�
Buon Dua)eu.kanade.tachiyomi.extension.all.buondua�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.buondua-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.buondua.png"1.4(
21.4.108B.�����Ҡ�Buon Duaall"https://buondua.com
�

Comic Fury+eu.kanade.tachiyomi.extension.all.comicfury�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicfury-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicfury.png"1.4(21.4.88B2�脲���G
Comic Furyall"https://comicfury.comB1�ɾӧ���V
Comic Furyen"https://comicfury.comB1����ྖE
Comic Furyes"https://comicfury.comB4�����ώx
Comic Furypt-BR"https://comicfury.comB1����ȼ��g
Comic Furyde"https://comicfury.comB1��џ����'
Comic Furyfr"https://comicfury.comB1��ơ����=
Comic Furyit"https://comicfury.comB1�Зќ���n
Comic Furypl"https://comicfury.comB1����ӎ��z
Comic Furyja"https://comicfury.comB1;������U
Comic Furyzh"https://comicfury.comB1������)
Comic Furyru"https://comicfury.comB1��������X
Comic Furyfi"https://comicfury.comB4�͍��̲�
Comic Furyother"https://comicfury.comB>�������#Comic Fury (No Text)other"https://comicfury.com
�
Comic Growl,eu.kanade.tachiyomi.extension.all.comicgrowl�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicgrowl-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicgrowl.png"1.4(21.4.128B5�������Comic Growlall"https://comic-growl.com
�

Comick (Unoriginal),eu.kanade.tachiyomi.extension.all.comicklive�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicklive-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicklive.png"1.4(21.4.58B8�����ځEComick (Unoriginal)en"https://comick.liveB8۔���ќ�Comick (Unoriginal)ru"https://comick.liveB8��������Comick (Unoriginal)vi"https://comick.liveB8�������0Comick (Unoriginal)fr"https://comick.liveB8�������FComick (Unoriginal)pl"https://comick.liveB8�͵�����|Comick (Unoriginal)id"https://comick.liveB8ӄ������nComick (Unoriginal)tr"https://comick.liveB8�כ؝���3Comick (Unoriginal)it"https://comick.liveB8���Ɵ���=Comick (Unoriginal)es"https://comick.liveB8ѭ��̹�KComick (Unoriginal)uk"https://comick.liveB8�񴧹�ˌ8Comick (Unoriginal)de"https://comick.liveB8������!Comick (Unoriginal)ko"https://comick.liveB8�����κ�Comick (Unoriginal)th"https://comick.liveB8�Ǵ�����9Comick (Unoriginal)ro"https://comick.liveB8�̊�����+Comick (Unoriginal)ms"https://comick.liveB8��������Comick (Unoriginal)ja"https://comick.liveB8ٗ����LComick (Unoriginal)sv"https://comick.liveB8���ĒŚ�'Comick (Unoriginal)no"https://comick.live
�
ComicsKingdom/eu.kanade.tachiyomi.extension.all.comicskingdom�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicskingdom-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicskingdom.png"1.4(21.4.38B<���Ӹ���.Comics Kingdomen"https://wp.comicskingdom.comB<����π��YComics Kingdomes"https://wp.comicskingdom.com
�
Comics Valley.eu.kanade.tachiyomi.extension.all.comicsvalley�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicsvalley-v1.4.53.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicsvalley.png"1.4(521.4.538B8�Ӫ���קComics Valleyall"https://comicsvalley.com
�
Comikey)eu.kanade.tachiyomi.extension.all.comikey�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comikey-v1.4.7.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comikey.png"1.4(21.4.78B,ͼ���֠�&Comikeyen"https://comikey.comB,ſ������Comikeyes"https://comikey.comB,�嗗����Comikeyid"https://comikey.comB/�������9Comikeypt-BR"https://comikey.comB9�����DComikey Brasilpt-BR"https://br.comikey.com
�
Commit Strip-eu.kanade.tachiyomi.extension.all.commitstrip�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.commitstrip-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.commitstrip.png"1.4(21.4.48B9Ԓ������ICommit Stripen"https://www.commitstrip.comB9��ܠ�Ў:Commit Stripfr"https://www.commitstrip.com
�
Coomer(eu.kanade.tachiyomi.extension.all.coomer�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.coomer-v1.4.24.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coomer.png"1.4(21.4.248B*�ƽ�����xCoomerall"https://coomer.st
�
	Corona EX*eu.kanade.tachiyomi.extension.all.coronaex�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.coronaex-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coronaex.png"1.4(21.4.18B3����ԌňB	Corona EXja"https://to-corona-ex.comB6��媩��w	Corona EXen"https://en.to-corona-ex.com
�
CosplayTele-eu.kanade.tachiyomi.extension.all.cosplaytele�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.cosplaytele-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cosplaytele.png"1.4(21.4.58B5���Ǿ�fCosplayTeleall"https://cosplaytele.com
�
Cubari(eu.kanade.tachiyomi.extension.all.cubari�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.cubari-v1.4.26.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cubari.png"1.4(21.4.268B*Ց�ݘ���WCubarien"https://cubari.moeB+��ಓ��Cubariall"https://cubari.moeB-�͙�в��Cubariother"https://cubari.moe
�
Danbooru*eu.kanade.tachiyomi.extension.all.danbooru�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.danbooru-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.danbooru.png"1.4(21.4.38B5��������iDanbooruall"https://danbooru.donmai.us
�

DeviantArt,eu.kanade.tachiyomi.extension.all.deviantart�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.deviantart-v1.4.10.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.deviantart.png"1.4(
21.4.108B7΋�̿���H
DeviantArtall"https://www.deviantart.com
�
Dragon Ball Multiverse6eu.kanade.tachiyomi.extension.all.dragonballmultiverse�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.dragonballmultiverse-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.dragonballmultiverse.png"1.4(21.4.88BM����آРQDragon Ball Multiverseen"%https://www.dragonball-multiverse.comBM����׆��nDragon Ball Multiversefr"%https://www.dragonball-multiverse.comBM���ך���Dragon Ball Multiverseja"%https://www.dragonball-multiverse.comBM���⭁��DDragon Ball Multiversezh"%https://www.dragonball-multiverse.comBM��������&Dragon Ball Multiversees"%https://www.dragonball-multiverse.comBMƭ������pDragon Ball Multiverseit"%https://www.dragonball-multiverse.comBM���Ѽܘ�LDragon Ball Multiversept"%https://www.dragonball-multiverse.comBM����̛�iDragon Ball Multiversede"%https://www.dragonball-multiverse.comBM������tDragon Ball Multiversepl"%https://www.dragonball-multiverse.comBM��᧷¾EDragon Ball Multiversenl"%https://www.dragonball-multiverse.comBT��ӏ���MDragon Ball Multiverse Parodyfr"%https://www.dragonball-multiverse.comBM��ݓ����gDragon Ball Multiversetr"%https://www.dragonball-multiverse.comBP�֗�ߺDragon Ball Multiversept-BR"%https://www.dragonball-multiverse.comBM������ХDragon Ball Multiversehu"%https://www.dragonball-multiverse.comBM���랻��ADragon Ball Multiversega"%https://www.dragonball-multiverse.comBM�������zDragon Ball Multiverseca"%https://www.dragonball-multiverse.comBM��Ћ╯�_Dragon Ball Multiverseno"%https://www.dragonball-multiverse.comBM����즽�nDragon Ball Multiverseru"%https://www.dragonball-multiverse.comBM����ޮ$Dragon Ball Multiversero"%https://www.dragonball-multiverse.comBM���ڊ���RDragon Ball Multiverseeu"%https://www.dragonball-multiverse.comBM�߀Ϗ��ODragon Ball Multiverselt"%https://www.dragonball-multiverse.comBM��ة����|Dragon Ball Multiversehr"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiverseko"%https://www.dragonball-multiverse.comBM����ٴ��+Dragon Ball Multiversefi"%https://www.dragonball-multiverse.comBM������GDragon Ball Multiversehe"%https://www.dragonball-multiverse.comBM���Ʈ���CDragon Ball Multiversebg"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiversesv"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiverseel"%https://www.dragonball-multiverse.comBQ�ؔ�����9Dragon Ball Multiversees-419"%https://www.dragonball-multiverse.comBM�ԡ�����3Dragon Ball Multiversear"%https://www.dragonball-multiverse.comBN�������,Dragon Ball Multiversefil"%https://www.dragonball-multiverse.comBM�µ�����8Dragon Ball Multiversela"%https://www.dragonball-multiverse.comBM���ϋ���+Dragon Ball Multiverseda"%https://www.dragonball-multiverse.comBM���猋��vDragon Ball Multiverseco"%https://www.dragonball-multiverse.comBM��ó��ެDragon Ball Multiversebr"%https://www.dragonball-multiverse.comBN���̀���^Dragon Ball Multiversevec"%https://www.dragonball-multiverse.comBN����Ƣ��zDragon Ball Multiverselmo"%https://www.dragonball-multiverse.com
�
e621&eu.kanade.tachiyomi.extension.all.e621�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.e621-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.e621.png"1.4(21.4.28B'�嶱����1e621all"https://e621.net
�
E-Hentai)eu.kanade.tachiyomi.extension.all.ehentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ehentai-v1.4.27.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ehentai.png"1.4(21.4.278B.�և���͵pE-Hentaija"https://e-hentai.orgB-����Ҟ�eE-Hentaien"https://e-hentai.orgB.�������@E-Hentaizh"https://e-hentai.orgB.���𓁾�E-Hentainl"https://e-hentai.orgB.ɢ��̆��6E-Hentaifr"https://e-hentai.orgB.�͘�찎�<E-Hentaide"https://e-hentai.orgB.��������
E-Hentaihu"https://e-hentai.orgB.ޙ������OE-Hentaiit"https://e-hentai.orgB.���ޮ��E-Hentaiko"https://e-hentai.orgB.ت��ٓ��TE-Hentaipl"https://e-hentai.orgB1�ϐ����cE-Hentaipt-BR"https://e-hentai.orgB.���㻡�E-Hentairu"https://e-hentai.orgB.զ�Ɩϋ*E-Hentaies"https://e-hentai.orgB.�䪝����RE-Hentaith"https://e-hentai.orgB.����褤TE-Hentaivi"https://e-hentai.orgB0�ɩ��ũ�LE-Hentainone"https://e-hentai.orgB1�옼��כUE-Hentaiother"https://e-hentai.org
�
Elite Babes,eu.kanade.tachiyomi.extension.all.elitebabes�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.elitebabes-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.elitebabes.png"1.4(21.4.28B8������^Elite Babesall"https://www.elitebabes.com
�
Everia.club,eu.kanade.tachiyomi.extension.all.everiaclub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.everiaclub-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclub.png"1.4(21.4.128B1����ծ��jEveria.cluball"https://everia.club
�
EveriaClub (unoriginal)/eu.kanade.tachiyomi.extension.all.everiaclubcom�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.everiaclubcom-v1.4.1.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclubcom.png"1.4(21.4.18BD���ج���xEveriaClub (unoriginal)all"https://www.everiaclub.com
�
Femjoy Hunter.eu.kanade.tachiyomi.extension.all.femjoyhunter�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.femjoyhunter-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.femjoyhunter.png"1.4(21.4.28B<ё�����Femjoy Hunterall"https://www.femjoyhunter.com
�
FoamGirl*eu.kanade.tachiyomi.extension.all.foamgirl�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.foamgirl-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foamgirl.png"1.4(21.4.58B/����켸�QFoamGirlall"https://foamgirl.net
�
FoolSlide Customizable7eu.kanade.tachiyomi.extension.all.foolslidecustomizable�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.foolslidecustomizable-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foolslidecustomizable.png"1.4(21.4.58B<������ޑXFoolSlide Customizableother"https://127.0.0.1
�
4KHD)eu.kanade.tachiyomi.extension.all.fourkhd�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.fourkhd-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.fourkhd.png"1.4(21.4.28B+�ϑ�����Z4KHDall"https://www.4khd.com
�

FTV Hunter+eu.kanade.tachiyomi.extension.all.ftvhunter�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ftvhunter-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ftvhunter.png"1.4(21.4.28B6֌������!
FTV Hunterall"https://www.ftvhunter.com
�
GlobalComix-eu.kanade.tachiyomi.extension.all.globalcomix�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.globalcomix-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.globalcomix.png"1.4(21.4.48B4������.GlobalComixsq"https://globalcomix.comB4�����GlobalComixar"https://globalcomix.comB4�������^GlobalComixbg"https://globalcomix.comB4��������GlobalComixbn"https://globalcomix.comB7�����Ɣ_GlobalComixpt-BR"https://globalcomix.comB9ϩ���ވ�cGlobalComixzh-Hans"https://globalcomix.comB4����Տ��?GlobalComixcs"https://globalcomix.comB4�����۸rGlobalComixde"https://globalcomix.comB4���ՇFGlobalComixda"https://globalcomix.comB4���҉���EGlobalComixel"https://globalcomix.comB4���Е���GlobalComixen"https://globalcomix.comB4���뷻��CGlobalComixes"https://globalcomix.comB4��١����*GlobalComixfa"https://globalcomix.comB4��蠰�ٌsGlobalComixfi"https://globalcomix.comB5����դ��cGlobalComixfil"https://globalcomix.comB4ރ览���GlobalComixfr"https://globalcomix.comB4Ä������lGlobalComixhi"https://globalcomix.comB4�ũ����GlobalComixhu"https://globalcomix.comB4��������PGlobalComixid"https://globalcomix.comB4ʎ؅�ѥ�	GlobalComixit"https://globalcomix.comB4������DGlobalComixhe"https://globalcomix.comB4������HGlobalComixja"https://globalcomix.comB4Ͳ������bGlobalComixko"https://globalcomix.comB4ߓ�����GlobalComixlv"https://globalcomix.comB4������ӑ8GlobalComixms"https://globalcomix.comB4������xGlobalComixnl"https://globalcomix.comB4�����ٖ�GlobalComixno"https://globalcomix.comB4��������}GlobalComixpl"https://globalcomix.comB4�Ý�ӣ��GlobalComixpt"https://globalcomix.comB4�����צ�GlobalComixro"https://globalcomix.comB4����Ѭ��wGlobalComixru"https://globalcomix.comB4��嬩౲2GlobalComixsv"https://globalcomix.comB4��Ļ;��-GlobalComixsk"https://globalcomix.comB4�۴�����GlobalComixsl"https://globalcomix.comB4��������LGlobalComixta"https://globalcomix.comB4�Կ����mGlobalComixth"https://globalcomix.comB4ߠ�����$GlobalComixtr"https://globalcomix.comB4��������GlobalComixuk"https://globalcomix.comB4��מ��GlobalComixur"https://globalcomix.comB4���ு��`GlobalComixvi"https://globalcomix.comB9����/GlobalComixzh-Hant"https://globalcomix.com
�
Grabber Zone-eu.kanade.tachiyomi.extension.all.grabberzone�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.grabberzone-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.grabberzone.png"1.4(321.4.518B3ɹ��칤�aGrabber Zoneall"https://grabber.zone
�
HDoujin)eu.kanade.tachiyomi.extension.all.hdoujin�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hdoujin-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hdoujin.png"1.4(21.4.48B-Λ��ݦ��HDoujinall"https://hdoujin.orgB,��ѡ���3HDoujinen"https://hdoujin.orgB,ǁ������[HDoujines"https://hdoujin.orgB,�ݟ��О@HDoujinja"https://hdoujin.orgB,�Ǭ�ڸ�tHDoujinko"https://hdoujin.orgB,����Ɲ��$HDoujinzh"https://hdoujin.org
�
Hennojin*eu.kanade.tachiyomi.extension.all.hennojin�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hennojin-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hennojin.png"1.4(21.4.38B.�у�����"Hennojinen"https://hennojin.comB.��������]Hennojinja"https://hennojin.com
�
3Hentai)eu.kanade.tachiyomi.extension.all.hentai3�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentai3-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentai3.png"1.4(21.4.38B-�����͞�_3Hentaiall"https://3hentai.netB,�ܭ⋊��l3Hentaien"https://3hentai.netB,��ѯ����'3Hentaija"https://3hentai.netB,��������3Hentaiko"https://3hentai.netB,��������V3Hentaizh"https://3hentai.netB,���Ƨ���w3Hentaimo"https://3hentai.netB,�������3Hentaies"https://3hentai.netB,���Љ���3Hentaipt"https://3hentai.netB+᷾�宅X3Hentaiid"https://3hentai.netB,�����¶�i3Hentaijv"https://3hentai.netB,�������63Hentaitl"https://3hentai.netB,�ԝ¾���T3Hentaivi"https://3hentai.netB,����ɖ�*3Hentaith"https://3hentai.netB,��ԗ���03Hentaimy"https://3hentai.netB,��������3Hentaitr"https://3hentai.netB,�������D3Hentairu"https://3hentai.netB,��֕�س�03Hentaiuk"https://3hentai.netB,����܄��n3Hentaipl"https://3hentai.netB,���ϥ��	3Hentaifi"https://3hentai.netB,��ƅܫ��a3Hentaide"https://3hentai.netB,�������3Hentaiit"https://3hentai.netB,��������;3Hentaifr"https://3hentai.netB,�������j3Hentainl"https://3hentai.netB,����䕽�53Hentaics"https://3hentai.netB,�������w3Hentaihu"https://3hentai.netB,���ğ��3Hentaibg"https://3hentai.netB,��������{3Hentaiis"https://3hentai.netB,�����忷E3Hentaila"https://3hentai.netB,�������3Hentaiar"https://3hentai.net
�
Hentai Cosplay/eu.kanade.tachiyomi.extension.all.hentaicosplay�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaicosplay-v1.4.8.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaicosplay.png"1.4(21.4.88B?Ŝ��֋¿/Hentai Cosplayall"https://hentai-cosplay-xxx.com
�

HentaiEnvy,eu.kanade.tachiyomi.extension.all.hentaienvy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaienvy-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaienvy.png"1.4(	21.4.98B2�掕��݄p
HentaiEnvyen"https://hentaienvy.comB2��ߔ�̍�n
HentaiEnvyja"https://hentaienvy.comB2��ڎ���
HentaiEnvyes"https://hentaienvy.comB2��������
HentaiEnvyfr"https://hentaienvy.comB2�����Ǐ�$
HentaiEnvyko"https://hentaienvy.comB2��Ϭ�"
HentaiEnvyde"https://hentaienvy.comB2���袃�\
HentaiEnvyru"https://hentaienvy.comB3��������
HentaiEnvyall"https://hentaienvy.com
�
	HentaiEra+eu.kanade.tachiyomi.extension.all.hentaiera�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaiera-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaiera.png"1.4(21.4.118B0�����ҷ�	HentaiEraen"https://hentaiera.comB0������"	HentaiEraja"https://hentaiera.comB0͵��̛��	HentaiEraes"https://hentaiera.comB0��ݬ���_	HentaiErafr"https://hentaiera.comB0��������R	HentaiErako"https://hentaiera.comB0���؜���	HentaiErade"https://hentaiera.comB0�ݏ�����D	HentaiEraru"https://hentaiera.comB1�������H	HentaiEraall"https://hentaiera.com
�
	HentaiFox+eu.kanade.tachiyomi.extension.all.hentaifox�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaifox-v1.4.16.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaifox.png"1.4(21.4.168B0䃇��ɛ�n	HentaiFoxen"https://hentaifox.comB0����䭊�w	HentaiFoxja"https://hentaifox.comB0��쬂��-	HentaiFoxzh"https://hentaifox.comB0�����ō�	HentaiFoxko"https://hentaifox.comB1���䖦�%	HentaiFoxall"https://hentaifox.com
�

HentaiHand,eu.kanade.tachiyomi.extension.all.hentaihand�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaihand-v1.4.10.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaihand.png"1.4(
21.4.108B3�������
HentaiHandall"https://hentaihand.comB2����֡��
HentaiHanden"https://hentaihand.comB2�����ǂ
HentaiHandzh"https://hentaihand.comB2��޲��ˤE
HentaiHandja"https://hentaihand.comB5��������e
HentaiHandother"https://hentaihand.comB2��������U
HentaiHandeo"https://hentaihand.comB3��������
HentaiHandceb"https://hentaihand.comB2��������^
HentaiHandcs"https://hentaihand.comB2��ި�� L
HentaiHandar"https://hentaihand.comB2أ���1
HentaiHandsk"https://hentaihand.comB2���د���:
HentaiHandmn"https://hentaihand.comB2����☒�
HentaiHanduk"https://hentaihand.comB2�������*
HentaiHandla"https://hentaihand.comB2��������q
HentaiHandtl"https://hentaihand.comB2��������
HentaiHandes"https://hentaihand.comB2���ɮ���r
HentaiHandit"https://hentaihand.comB2�ؤ����&
HentaiHandko"https://hentaihand.comB2�ꆭ�
HentaiHandth"https://hentaihand.comB2������U
HentaiHandpl"https://hentaihand.comB2��������
HentaiHandfr"https://hentaihand.comB5��ԃ����"
HentaiHandpt-BR"https://hentaihand.comB2�����翘s
HentaiHandde"https://hentaihand.comB2�����צ�C
HentaiHandfi"https://hentaihand.comB2��쟴�ݩP
HentaiHandru"https://hentaihand.comB2�絝����Z
HentaiHandhu"https://hentaihand.comB2��������
HentaiHandid"https://hentaihand.comB2�᬴�Ҫ�
HentaiHandvi"https://hentaihand.comB2्��ې�m
HentaiHandnl"https://hentaihand.comB2��������
HentaiHandhi"https://hentaihand.comB2����䄿W
HentaiHandtr"https://hentaihand.comB2���˰�~
HentaiHandel"https://hentaihand.comB2�毝���
HentaiHandsr"https://hentaihand.comB2�����ϸq
HentaiHandjv"https://hentaihand.comB2���ɶ���h
HentaiHandbg"https://hentaihand.com
�
	HentaiRox+eu.kanade.tachiyomi.extension.all.hentairox�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentairox-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentairox.png"1.4(	21.4.98B0ʕ������&	HentaiRoxen"https://hentairox.comB0��������	HentaiRoxja"https://hentairox.comB0��ޜ��/	HentaiRoxzh"https://hentairox.comB1��ĕ����-	HentaiRoxall"https://hentairox.com
�
	HentaiZap+eu.kanade.tachiyomi.extension.all.hentaizap�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaizap-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaizap.png"1.4(	21.4.98B0➞����*	HentaiZapen"https://hentaizap.comB0������Z	HentaiZapja"https://hentaizap.comB0��������B	HentaiZapes"https://hentaizap.comB0��������m	HentaiZapfr"https://hentaizap.comB0��������	HentaiZapko"https://hentaizap.comB0�ϯ��Ԉ�	HentaiZapde"https://hentaizap.comB0���٘���[	HentaiZapru"https://hentaizap.comB1�І�����	HentaiZapall"https://hentaizap.com
�
Hitomi(eu.kanade.tachiyomi.extension.all.hitomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hitomi-v1.4.41.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hitomi.png"1.4()21.4.418B*񼐏����	Hitomiall"https://hitomi.laB)�혷����yHitomien"https://hitomi.laB)��������Hitomiid"https://hitomi.laB)�З�����ZHitomijv"https://hitomi.laB)ݰ�Յ���ZHitomica"https://hitomi.laB*�ِ�����9Hitomiceb"https://hitomi.laB)񹆄����VHitomics"https://hitomi.laB)��ڇ����Hitomida"https://hitomi.laB)�������0Hitomide"https://hitomi.laB)��������+Hitomiet"https://hitomi.laB)���՛���@Hitomies"https://hitomi.laB)�抁����&Hitomieo"https://hitomi.laB)����矷�"Hitomifr"https://hitomi.laB)ȟ���Ԫ�_Hitomiit"https://hitomi.laB)�������Hitomihi"https://hitomi.laB)���Р��RHitomihu"https://hitomi.laB)С��꒻�
Hitomipl"https://hitomi.laB)�����JHitomipt"https://hitomi.laB)�ǜ�����4Hitomivi"https://hitomi.laB)��ް���JHitomitr"https://hitomi.laB)꙰�����6Hitomiru"https://hitomi.laB)��������8Hitomiuk"https://hitomi.laB)�է��ޙ�^Hitomiar"https://hitomi.laB)��齓���}Hitomiko"https://hitomi.laB)�����ߗ�Hitomizh"https://hitomi.laB)�ެ����cHitomija"https://hitomi.la
�
HNI-Scantrad-eu.kanade.tachiyomi.extension.all.hniscantrad�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hniscantrad-v1.4.9.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hniscantrad.png"1.4(	21.4.98B7��������EHNI-Scantradall"https://hni-scantrad.net
�
HOLONOMETRIA.eu.kanade.tachiyomi.extension.all.holonometria�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.holonometria-v1.4.4.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.holonometria.png"1.4(21.4.48B3�茿���yHOLONOMETRIAja"https://holoearth.comB3��������HOLONOMETRIAen"https://holoearth.comB3��ƀ΍��FHOLONOMETRIAid"https://holoearth.com
�
	Honeytoon+eu.kanade.tachiyomi.extension.all.honeytoon�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.honeytoon-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.honeytoon.png"1.4(21.4.28B0�����җ�w	Honeytoonde"https://honeytoon.comB0�������	Honeytoonen"https://honeytoon.comB0�������L	Honeytoones"https://honeytoon.comB0�ʭ��ܟ�[	Honeytoonfr"https://honeytoon.comB0��������}	Honeytoonit"https://honeytoon.comB3�ݠ�����g	Honeytoonpt-BR"https://honeytoon.com
�
IMHentai*eu.kanade.tachiyomi.extension.all.imhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.imhentai-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.imhentai.png"1.4(21.4.248B.�������IMHentaien"https://imhentai.xxxB.��롈���'IMHentaija"https://imhentai.xxxB.�ŀ����IMHentaies"https://imhentai.xxxB.���̻ZIMHentaifr"https://imhentai.xxxB.ؽ�ڧ�ԜIMHentaiko"https://imhentai.xxxB.�る����IMHentaide"https://imhentai.xxxB.������єhIMHentairu"https://imhentai.xxxB/������Ə/IMHentaiall"https://imhentai.xxx
�
izneo (webtoons)'eu.kanade.tachiyomi.extension.all.izneo�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.izneo-v1.4.8.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.izneo.png"1.4(21.4.88B7ÿ���꠰cizneoen" https://www.izneo.com/en/webtoonB7������izneofr" https://www.izneo.com/fr/webtoon
�
JJCOS'eu.kanade.tachiyomi.extension.all.jjcos�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.jjcos-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.jjcos.png"1.4(21.4.18B)�����OJJCOSall"https://jjcos.com
�

Joymii Hub+eu.kanade.tachiyomi.extension.all.joymiihub�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.joymiihub-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.joymiihub.png"1.4(21.4.28B6���濲��t
Joymii Huball"https://www.joymiihub.com
�
Junmeitu*eu.kanade.tachiyomi.extension.all.junmeitu�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.junmeitu-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.junmeitu.png"1.4(21.4.78B/쒍�����AJunmeituall"https://meijuntu.com
�
Kagane(eu.kanade.tachiyomi.extension.all.kagane�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kagane-v1.4.26.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kagane.png"1.4(21.4.268B)�չ����7Kaganeen"https://kagane.toB)�퐿����Kaganeja"https://kagane.toB)��������Kaganeko"https://kagane.toB)��к����Kaganezh"https://kagane.toB)�������WKaganees"https://kagane.toB-������׋-Kaganees-419"https://kagane.toB)դ���ʧ�TKaganefr"https://kagane.toB)�ս�ڥ��Kaganede"https://kagane.toB)��������-Kaganept"https://kagane.toB,�ݩ�����{Kaganept-BR"https://kagane.toB)�ㄒ��yKaganeru"https://kagane.toB)��������Kaganeit"https://kagane.toB)������jKaganeid"https://kagane.toB)���鋑ׁzKaganevi"https://kagane.toB)�ӳ�����Kaganeth"https://kagane.toB)��Г�џ�Kaganepl"https://kagane.toB)�����ײ�}Kaganehi"https://kagane.toB)�����ʍmKaganear"https://kagane.to
�
Kemono(eu.kanade.tachiyomi.extension.all.kemono�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kemono-v1.4.25.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kemono.png"1.4(21.4.258B*��������Kemonoall"https://kemono.cr
�
Kiutaku)eu.kanade.tachiyomi.extension.all.kiutaku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kiutaku-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kiutaku.png"1.4(21.4.68B-�Щ�����*Kiutakuall"https://kiutaku.com
�
Kodoku Studio.eu.kanade.tachiyomi.extension.all.kodokustudio�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kodokustudio-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kodokustudio.png"1.4(321.4.518B8�����Kodoku Studioall"https://kodokustudio.com
�
SchaleNetwork(eu.kanade.tachiyomi.extension.all.koharu�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.koharu-v1.4.20.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.koharu.png"1.4(21.4.208B6�����ߏ�	SchaleNetworkall"https://schale.networkB5���͉���SchaleNetworken"https://schale.networkB5��������vSchaleNetworkja"https://schale.networkB5����ψ��zSchaleNetworkzh"https://schale.network
�
Komga'eu.kanade.tachiyomi.extension.all.komga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.komga-v1.4.65.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.komga.png"1.4(A21.4.658BЧ����>KomgaallB����Ǻ��p	Komga (2)allB��ۖ��ڝG	Komga (3)all
�
	LANraragi+eu.kanade.tachiyomi.extension.all.lanraragi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.lanraragi-v1.4.21.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lanraragi.png"1.4(21.4.218B5����惾�>LANraragi (1)all"http://127.0.0.1:3000B5�����ә�ULANraragi (2)all"http://127.0.0.1:3000
�
League of Legends1eu.kanade.tachiyomi.extension.all.leagueoflegends�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.leagueoflegends-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.leagueoflegends.png"1.4(21.4.28BTَ���駞KLeague of Legendsen"1https://universe.leagueoflegends.com/en_us/comic/BT���ۇ��League of Legendsde"1https://universe.leagueoflegends.com/de_de/comic/BT��������"League of Legendses"1https://universe.leagueoflegends.com/es_es/comic/BT�罷�؛�{League of Legendsfr"1https://universe.leagueoflegends.com/fr_fr/comic/BT��ќ����)League of Legendsit"1https://universe.leagueoflegends.com/it_it/comic/BT��������8League of Legendspl"1https://universe.leagueoflegends.com/pl_pl/comic/BT�������/League of Legendsel"1https://universe.leagueoflegends.com/el_gr/comic/BT��������qLeague of Legendsro"1https://universe.leagueoflegends.com/ro_ro/comic/BTѣ������vLeague of Legendshu"1https://universe.leagueoflegends.com/hu_hu/comic/BT��������League of Legendscs"1https://universe.leagueoflegends.com/cs_cz/comic/BX��������,League of Legendses-419"1https://universe.leagueoflegends.com/es_mx/comic/BW��������jLeague of Legendspt-BR"1https://universe.leagueoflegends.com/pt_br/comic/BT߉�ׯ�ϸLeague of Legendsja"1https://universe.leagueoflegends.com/ja_jp/comic/BT�����ݸ�XLeague of Legendsru"1https://universe.leagueoflegends.com/ru_ru/comic/BT��������ELeague of Legendstr"1https://universe.leagueoflegends.com/tr_tr/comic/BTЌ�򰁥League of Legendsko"1https://universe.leagueoflegends.com/ko_kr/comic/
�
Lunar Manga,eu.kanade.tachiyomi.extension.all.lunaranime�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.lunaranime-v1.4.8.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lunaranime.png"1.4(21.4.88B3��������PLunar Mangaall"https://lunaranime.ruB2�������eLunar Mangaen"https://lunaranime.ruB2��������3Lunar Mangaar"https://lunaranime.ruB2����ÿ�%Lunar Mangabg"https://lunaranime.ruB2ϴ���鿥1Lunar Mangabn"https://lunaranime.ruB2�㊚����Lunar Mangada"https://lunaranime.ruB2ԅ�̌���DLunar Mangade"https://lunaranime.ruB2��«椥�Lunar Mangaes"https://lunaranime.ruB6�ێ�����?Lunar Mangaes-419"https://lunaranime.ruB2ܬ������kLunar Mangafa"https://lunaranime.ruB2��꽄���Lunar Mangafi"https://lunaranime.ruB2�����sLunar Mangafr"https://lunaranime.ruB2Ǳ��ə��DLunar Mangahe"https://lunaranime.ruB2�ǹ�����>Lunar Mangahi"https://lunaranime.ruB2��������pLunar Mangaid"https://lunaranime.ruB2�����rLunar Mangait"https://lunaranime.ruB2���ʠ���'Lunar Mangaja"https://lunaranime.ruB2Ҍٳډ��RLunar Mangako"https://lunaranime.ruB2�������Lunar Mangams"https://lunaranime.ruB2��ܳ���Lunar Manganl"https://lunaranime.ruB2����آ��Lunar Mangano"https://lunaranime.ruB2��캚��Lunar Mangapl"https://lunaranime.ruB2��������	Lunar Mangapt"https://lunaranime.ruB5ȝ������Lunar Mangapt-BR"https://lunaranime.ruB2��������BLunar Mangaru"https://lunaranime.ruB2�ܥ�ݲ��=Lunar Mangasv"https://lunaranime.ruB2�ԁ�����+Lunar Mangath"https://lunaranime.ruB2�������`Lunar Mangatl"https://lunaranime.ruB2�������5Lunar Mangatr"https://lunaranime.ruB2լ������,Lunar Mangaur"https://lunaranime.ruB2�ٳ꘨ƇELunar Mangavi"https://lunaranime.ruB2����ޖ��)Lunar Mangazh"https://lunaranime.ru
�
Luscious*eu.kanade.tachiyomi.extension.all.luscious�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.luscious-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.luscious.png"1.4( 21.4.328B2��Ϲ濨�&Lusciousen"https://www.luscious.netB2��������Lusciousja"https://www.luscious.netB2ۥ����;Lusciouses"https://www.luscious.netB2���ٯ�Lusciousit"https://www.luscious.netB2�������GLusciousde"https://www.luscious.netB2��݁߶�Lusciousfr"https://www.luscious.netB2Ȓѵ��HLusciouszh"https://www.luscious.netB2�������Lusciousko"https://www.luscious.netB5򼡄̓ÙLusciousother"https://www.luscious.netB5���⟆��PLusciouspt-BR"https://www.luscious.netB2�������$Lusciousth"https://www.luscious.netB3����ߛ�@Lusciousall"https://www.luscious.net
�
Magical Translators4eu.kanade.tachiyomi.extension.all.magicaltranslators�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.magicaltranslators-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.magicaltranslators.png"1.4(21.4.88B>�ë҃���7Magical Translatorsen"https://mahoushoujobu.comB>���쭪ţxMagical Translatorses"https://mahoushoujobu.comB>��������Magical Translatorspl"https://mahoushoujobu.com
�
	Manga18Me+eu.kanade.tachiyomi.extension.all.manga18me�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manga18me-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manga18me.png"1.4(21.4.38B/���ĺ��
Manga18.meall"https://manga18.meB.��ԛ����V
Manga18.meen"https://manga18.me
�

Manga Ball+eu.kanade.tachiyomi.extension.all.mangaball�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaball-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaball.png"1.4(21.4.38B1ޗԔ����O
Manga Ballar"https://mangaball.netB1���ٴ���y
Manga Ballbg"https://mangaball.netB1�������
Manga Ballbn"https://mangaball.netB1��������~
Manga Ballca"https://mangaball.netB1�������c
Manga Ballcs"https://mangaball.netB1ҥ������0
Manga Ballda"https://mangaball.netB1��Ӝ����
Manga Ballde"https://mangaball.netB1�ү����M
Manga Ballel"https://mangaball.netB1�������
Manga Ballen"https://mangaball.netB1���Ԉ�
Manga Balles"https://mangaball.netB1���Ӓ���E
Manga Ballfa"https://mangaball.netB1��ۧį��J
Manga Ballfi"https://mangaball.netB1���ï���B
Manga Ballfr"https://mangaball.netB1�������!
Manga Ballhe"https://mangaball.netB1�ͩ�����.
Manga Ballhi"https://mangaball.netB0�䯂�ʏ=
Manga Ballhu"https://mangaball.netB1騏ᨺ��'
Manga Ballid"https://mangaball.netB1�����ݾ�1
Manga Ballit"https://mangaball.netB1����­ƕb
Manga Ballis"https://mangaball.netB1��Ӥ���1
Manga Ballja"https://mangaball.netB1�Ҽ�ɮ��[
Manga Ballko"https://mangaball.netB1�п�����y
Manga Ballkn"https://mangaball.netB1��ý̸��?
Manga Ballml"https://mangaball.netB1����С��r
Manga Ballms"https://mangaball.netB1Ӫ������
Manga Ballne"https://mangaball.netB1������L
Manga Ballnl"https://mangaball.netB1���ϝ��4
Manga Ballno"https://mangaball.netB1����݅�P
Manga Ballpl"https://mangaball.netB3ǔ�����?
Manga Ballpt-BR"https://mangaball.netB1��˗ҩ��.
Manga Ballro"https://mangaball.netB1���Ԯ۟�c
Manga Ballru"https://mangaball.netB1��ј����p
Manga Ballsk"https://mangaball.netB1��ѵѝ�
Manga Ballsl"https://mangaball.netB1��ǭ����n
Manga Ballsq"https://mangaball.netB1�������@
Manga Ballsr"https://mangaball.netB1�Џ�����D
Manga Ballsv"https://mangaball.netB1�����ӝ�
Manga Ballta"https://mangaball.netB1�����〉^
Manga Ballth"https://mangaball.netB1��ץ�ˏ�x
Manga Balltr"https://mangaball.netB1����ˬ��U
Manga Balluk"https://mangaball.netB1Ĭ��Ÿ��
Manga Ballvi"https://mangaball.netB1��������
Manga Ballzh"https://mangaball.net
�

MangaCrazy,eu.kanade.tachiyomi.extension.all.mangacrazy�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangacrazy-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangacrazy.png"1.4(321.4.518B3�Ϧ�����^
MangaCrazyall"https://mangacrazy.net
�
MangaDex*eu.kanade.tachiyomi.extension.all.mangadex�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadex-v1.4.210.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadex.png"1.4(�21.4.2108B.���ׯ���"MangaDexen"https://mangadex.orgB.��֑����@MangaDexaf"https://mangadex.orgB.��ɻ����MangaDexsq"https://mangadex.orgB.��������.MangaDexar"https://mangadex.orgB.��������~MangaDexaz"https://mangadex.orgB.��������MangaDexeu"https://mangadex.orgB.͒������1MangaDexbe"https://mangadex.orgB.���˨���9MangaDexbn"https://mangadex.orgB.ğ͌필�KMangaDexbg"https://mangadex.orgB.�؂����MangaDexmy"https://mangadex.orgB.�����贪QMangaDexca"https://mangadex.orgB3��������GMangaDexzh-Hans"https://mangadex.orgB3��������MangaDexzh-Hant"https://mangadex.orgB.����庡�MangaDexcv"https://mangadex.orgB.򍀿����vMangaDexhr"https://mangadex.orgB.�Κ����1MangaDexcs"https://mangadex.orgB.�����MangaDexda"https://mangadex.orgB.���خ��]MangaDexnl"https://mangadex.orgB.���΂���'MangaDexeo"https://mangadex.orgB.�����݂�yMangaDexet"https://mangadex.orgB/�����ё�wMangaDexfil"https://mangadex.orgB.ǲ����rMangaDexfi"https://mangadex.orgB.������>MangaDexfr"https://mangadex.orgB.�ܹ�����|MangaDexka"https://mangadex.orgB.���㦜��FMangaDexde"https://mangadex.orgB.��䕠-MangaDexel"https://mangadex.orgB.��������MangaDexhe"https://mangadex.orgB.�������^MangaDexhi"https://mangadex.orgB.�ߏ��̻;MangaDexhu"https://mangadex.orgB.�����׃�3MangaDexga"https://mangadex.orgB.�񎥝��4MangaDexid"https://mangadex.orgB.������ɋMangaDexit"https://mangadex.orgB.����Ӄ��MangaDexjv"https://mangadex.orgB.���ڧ���MangaDexja"https://mangadex.orgB.и���굥{MangaDexkk"https://mangadex.orgB.ضĘ����-MangaDexko"https://mangadex.orgB.��������
MangaDexla"https://mangadex.orgB.Ƈ�ҥ���
MangaDexlt"https://mangadex.orgB.��ӄ����MangaDexms"https://mangadex.orgB.���ұ���RMangaDexmn"https://mangadex.orgB.��׈���MangaDexne"https://mangadex.orgB.����̅��CMangaDexno"https://mangadex.orgB.���ĵ��4MangaDexfa"https://mangadex.orgB.܍ώ����oMangaDexpl"https://mangadex.orgB1��ݹ����$MangaDexpt-BR"https://mangadex.orgB.��ƕ���HMangaDexpt"https://mangadex.orgB.�߱൳��BMangaDexro"https://mangadex.orgB.��峐MangaDexru"https://mangadex.orgB.����趭�0MangaDexsr"https://mangadex.orgB.�Ŭ�����'MangaDexsk"https://mangadex.orgB2�͎�����DMangaDexes-419"https://mangadex.orgB.��乔���XMangaDexes"https://mangadex.orgB.����̨��MangaDexsv"https://mangadex.orgB.״�����;MangaDexta"https://mangadex.orgB.���Ľ���_MangaDexte"https://mangadex.orgB.��������MangaDexth"https://mangadex.orgB.���Į���5MangaDextr"https://mangadex.orgB.�����љPMangaDexuk"https://mangadex.orgB.ݷ���ꨁMangaDexur"https://mangadex.orgB.������ɲ'MangaDexuz"https://mangadex.orgB.洛����MangaDexvi"https://mangadex.org
�
MangaDNA*eu.kanade.tachiyomi.extension.all.mangadna�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadna-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadna.png"1.4(21.4.28B.�������GMangaDNAen"https://mangadna.comB/��������VMangaDNAall"https://mangadna.com
�
Manga Draft,eu.kanade.tachiyomi.extension.all.mangadraft�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadraft-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadraft.png"1.4(21.4.18B3��ϳ�ń�_
MangaDraftall"https://mangadraft.com
�
	MangaFire+eu.kanade.tachiyomi.extension.all.mangafire�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangafire-v1.4.24.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangafire.png"1.4(21.4.248B/�������T	MangaFireen"https://mangafire.toB/��ç���p	MangaFirees"https://mangafire.toB3��˽��5	MangaFirees-419"https://mangafire.toB/����֞��V	MangaFirefr"https://mangafire.toB/����׃��	MangaFireja"https://mangafire.toB/ۄ�ʾ���
	MangaFirept"https://mangafire.toB2�����ȷ�l	MangaFirept-BR"https://mangafire.to
�
MangaForFree.net.eu.kanade.tachiyomi.extension.all.mangaforfree�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaforfree-v1.4.53.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaforfree.png"1.4(521.4.538B:�ӏ��Ѷ�gMangaForFree.neten"https://mangaforfree.netB:�ϗր�ѭMangaForFree.netko"https://mangaforfree.netB:�������MangaForFree.netall"https://mangaforfree.net
�
MANGA Plus by SHUEISHA+eu.kanade.tachiyomi.extension.all.mangaplus�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaplus-v1.4.62.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaplus.png"1.4(>21.4.628BH��������MANGA Plus by SHUEISHAen" https://mangaplus.shueisha.co.jpBHΦ��ڙ��MANGA Plus by SHUEISHAes" https://mangaplus.shueisha.co.jpBH�ـ�����jMANGA Plus by SHUEISHAfr" https://mangaplus.shueisha.co.jpBH﷯����MANGA Plus by SHUEISHAid" https://mangaplus.shueisha.co.jpBK�������/MANGA Plus by SHUEISHApt-BR" https://mangaplus.shueisha.co.jpBH��ć���0MANGA Plus by SHUEISHAru" https://mangaplus.shueisha.co.jpBH����ߓ��XMANGA Plus by SHUEISHAth" https://mangaplus.shueisha.co.jpBH������AMANGA Plus by SHUEISHAvi" https://mangaplus.shueisha.co.jpBH�����ǣMANGA Plus by SHUEISHAde" https://mangaplus.shueisha.co.jp
�
MANGA Plus Creators by SHUEISHA3eu.kanade.tachiyomi.extension.all.mangapluscreators�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangapluscreators-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangapluscreators.png"1.4(21.4.38BN�Ѧ�Ť��EMANGA Plus Creators by SHUEISHAen"https://mangaplus-creators.jpBN��������MANGA Plus Creators by SHUEISHAes"https://mangaplus-creators.jp
�
	MangaTaro+eu.kanade.tachiyomi.extension.all.mangataro�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangataro-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangataro.png"1.4(21.4.118B0��Ȥ����s	MangaTaroen"https://mangataro.orgB3֖������	MangaTaropt-BR"https://mangataro.org
�
MangaToon (Limited)+eu.kanade.tachiyomi.extension.all.mangatoon�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangatoon-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangatoon.png"1.4(21.4.88B;����␂�NMangaToon (Limited)zh"https://mangatoon.mobiB;�ڨ�����BMangaToon (Limited)en"https://mangatoon.mobiB;�޾�紬�[MangaToon (Limited)id"https://mangatoon.mobiB;������_MangaToon (Limited)vi"https://mangatoon.mobiB;��웧羦MangaToon (Limited)es"https://mangatoon.mobiB>���Ӽ��MangaToon (Limited)pt-BR"https://mangatoon.mobiB;��������VMangaToon (Limited)th"https://mangatoon.mobiB;��б����\MangaToon (Limited)fr"https://mangatoon.mobiB;��������0MangaToon (Limited)ja"https://mangatoon.mobi
�
	Manga UP!)eu.kanade.tachiyomi.extension.all.mangaup�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaup-v1.4.8.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaup.png"1.4(21.4.88B6��������j	Manga UP!en"https://global.manga-up.com
�
Mango'eu.kanade.tachiyomi.extension.all.mango�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mango-v1.4.11.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mango.png"1.4(21.4.118Bχ����(Mangoen
�
Manhuarm*eu.kanade.tachiyomi.extension.all.manhuarm�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhuarm-v1.4.76.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhuarm.png"1.4(L21.4.768B0竨ͣ���Manhuarmar"https://manhuarmtl.comB0�ç����jManhuarmen"https://manhuarmtl.comB0�������vManhuarmes"https://manhuarmtl.comB0����׍��vManhuarmfr"https://manhuarmtl.comB0������ݎYManhuarmid"https://manhuarmtl.comB0��˴ۣ�iManhuarmit"https://manhuarmtl.comB3�ܢ�����MManhuarmpt-BR"https://manhuarmtl.com
�
Manhwa18.cc,eu.kanade.tachiyomi.extension.all.manhwa18cc�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18cc-v1.4.58.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18cc.png"1.4(:21.4.588B0������CManhwa18.ccen"https://manhwa18.ccB0߇������_Manhwa18.ccko"https://manhwa18.ccB1�������Manhwa18.ccall"https://manhwa18.cc
�
Manhwa18.net-eu.kanade.tachiyomi.extension.all.manhwa18net�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18net-v1.4.13.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18net.png"1.4(21.4.138B2��������	Manhwa18.Neten"https://manhwa18.net
�
Manhwa 18 Uncensored4eu.kanade.tachiyomi.extension.all.manhwa18uncensored�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18uncensored-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18uncensored.png"1.4(321.4.518BD��������xManhwa 18 Uncensoreden"https://manhwa18uncensored.comBE��ނ����Manhwa 18 Uncensoredall"https://manhwa18uncensored.com
�
ManhwaClub.net/eu.kanade.tachiyomi.extension.all.manhwaclubnet�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwaclubnet-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwaclubnet.png"1.4(321.4.518B6�ӧ�봫�]ManhwaClub.neten"https://manhwaclub.netB6��鄐�ʪ0ManhwaClub.netko"https://manhwaclub.net
�

Manhwa-raw/eu.kanade.tachiyomi.extension.all.manhwadashraw�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwadashraw-v1.4.53.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwadashraw.png"1.4(521.4.538B3�����Ǩ�M
Manhwa-rawall"https://manhwa-raw.com
�
Manta Comics'eu.kanade.tachiyomi.extension.all.manta�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manta-v1.4.9.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manta.png"1.4(	21.4.98B+·˞��ϼyMantaen"https://manta.net/enB+�������'Mantaes"https://manta.net/es
�
MayoTune*eu.kanade.tachiyomi.extension.all.mayotune�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mayotune-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mayotune.png"1.4(21.4.28B.��Ҝ����MayoTuneen"https://mayochuu.xyzB.��������\MayoTuneja"https://mayochuu.xyz
�
Metart Hunter.eu.kanade.tachiyomi.extension.all.metarthunter�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.metarthunter-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.metarthunter.png"1.4(21.4.28B<��������1Metart Hunterall"https://www.metarthunter.com
�
	Miau Scan*eu.kanade.tachiyomi.extension.all.miauscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.miauscan-v1.4.39.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.miauscan.png"1.4('21.4.398B.�����Ɍ�(	Miau Scanes"https://leemiau.comB1�����ې�]	Miau Scanpt-BR"https://leemiau.com
�
MissKon)eu.kanade.tachiyomi.extension.all.misskon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.misskon-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.misskon.png"1.4(21.4.48B-��������MissKonall"https://misskon.com
�
Mitaku(eu.kanade.tachiyomi.extension.all.mitaku�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mitaku-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mitaku.png"1.4(21.4.48B+֝������hMitakuall"https://mitaku.net
�
MyReadingManga0eu.kanade.tachiyomi.extension.all.myreadingmanga�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.myreadingmanga-v1.4.61.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.myreadingmanga.png"1.4(=21.4.618B;ή놌���CMyReadingMangaar"https://myreadingmanga.infoB;屹�����zMyReadingMangaid"https://myreadingmanga.infoB;���봚��sMyReadingMangazh"https://myreadingmanga.infoB;��ᛐ���WMyReadingMangaen"https://myreadingmanga.infoB;����ԥ�MyReadingMangade"https://myreadingmanga.infoB;��������.MyReadingMangait"https://myreadingmanga.infoB;�ب�����iMyReadingMangaja"https://myreadingmanga.infoB;��ݪ����sMyReadingMangako"https://myreadingmanga.infoB>􄕆�ՠ�bMyReadingMangapt-BR"https://myreadingmanga.infoB;�����ռ:MyReadingMangaru"https://myreadingmanga.infoB;�筦Ќ��1MyReadingMangaes"https://myreadingmanga.infoB;П�ݻ���MyReadingMangatr"https://myreadingmanga.infoB;�ؙ���9MyReadingMangavi"https://myreadingmanga.info
�
NamiComi*eu.kanade.tachiyomi.extension.all.namicomi�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.namicomi-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.namicomi.png"1.4(21.4.68B.Կ�����^NamiComien"https://namicomi.comB.����Έ��lNamiComiar"https://namicomi.comB.��������mNamiComibg"https://namicomi.comB.���̫���JNamiComica"https://namicomi.comB3��������NamiComizh-Hans"https://namicomi.comB3���޼�mNamiComizh-Hant"https://namicomi.comB.޹ě֌��NamiComihr"https://namicomi.comB.޿�����NamiComics"https://namicomi.comB.��������hNamiComida"https://namicomi.comB.����Ġ��9NamiCominl"https://namicomi.comB.�ﭐ����NamiComiet"https://namicomi.comB/��鿲���lNamiComifil"https://namicomi.comB.������{NamiComifi"https://namicomi.comB.�����Ȣ�%NamiComifr"https://namicomi.comB.��������[NamiComide"https://namicomi.comB.��ʆ����jNamiComiel"https://namicomi.comB.������׫NamiComihe"https://namicomi.comB.����ݱ��RNamiComihi"https://namicomi.comB.�����lNamiComihu"https://namicomi.comB.�ل�����NamiComiis"https://namicomi.comB.ѯ��ϸш1NamiComiga"https://namicomi.comB.���ۗͯ�NamiComiid"https://namicomi.comB.���ڼ���RNamiComiit"https://namicomi.comB.��Ŧ큁�_NamiComija"https://namicomi.comB.������NamiComiko"https://namicomi.comB.�너����UNamiComilt"https://namicomi.comB.��Ԭ����TNamiComims"https://namicomi.comB.�����ጏNamiComine"https://namicomi.comB.�����ݥ�[NamiComino"https://namicomi.comB.��悾���
NamiComipa"https://namicomi.comB.����˂��NamiComifa"https://namicomi.comB.�������INamiComipl"https://namicomi.comB1�����鳺NamiComipt-BR"https://namicomi.comB.��ќ���BNamiComipt"https://namicomi.comB.���ᆽ��NamiComiru"https://namicomi.comB.�׎�����NamiComisk"https://namicomi.comB.��������NamiComisl"https://namicomi.comB2��է���3NamiComies-419"https://namicomi.comB.��������gNamiComies"https://namicomi.comB.��ި����7NamiComisv"https://namicomi.comB.렩�����^NamiComith"https://namicomi.comB.Ȑ�ϣ��NamiComitr"https://namicomi.comB.�ޢ����gNamiComiuk"https://namicomi.com
�
NHentai)eu.kanade.tachiyomi.extension.all.nhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentai-v1.4.60.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentai.png"1.4(<21.4.608B,�Ѧ�����+NHentaien"https://nhentai.netB,�ᘘ����ANHentaija"https://nhentai.netB,����ŗ��NHentaizh"https://nhentai.netB-��������eNHentaiall"https://nhentai.net
�
nHentai.com (unoriginal),eu.kanade.tachiyomi.extension.all.nhentaicom�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentaicom-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaicom.png"1.4(	21.4.98B>�߯���nHentai.com (unoriginal)all"https://nhentai.comB=�����vnHentai.com (unoriginal)zh"https://nhentai.comB=��צ����MnHentai.com (unoriginal)en"https://nhentai.comB=�Ә�����qnHentai.com (unoriginal)ja"https://nhentai.comB@��������PnHentai.com (unoriginal)other"https://nhentai.comB=���ʧ���nHentai.com (unoriginal)ar"https://nhentai.comB=�������EnHentai.com (unoriginal)jv"https://nhentai.comB=׬��՞��JnHentai.com (unoriginal)bg"https://nhentai.comB=ĸ������nHentai.com (unoriginal)cs"https://nhentai.comB=���♗��nHentai.com (unoriginal)uk"https://nhentai.comB=��컸���qnHentai.com (unoriginal)sk"https://nhentai.comB=��환���KnHentai.com (unoriginal)eo"https://nhentai.comB=쏯�ß��2nHentai.com (unoriginal)mn"https://nhentai.comB=����ӄ��]nHentai.com (unoriginal)la"https://nhentai.comB>��͡��snHentai.com (unoriginal)ceb"https://nhentai.comB=ʥ���߹�<nHentai.com (unoriginal)tl"https://nhentai.comB=��ֱ����vnHentai.com (unoriginal)fi"https://nhentai.comB=�ӣ���͑YnHentai.com (unoriginal)tr"https://nhentai.comB=�喙����nHentai.com (unoriginal)sr"https://nhentai.comB=�������SnHentai.com (unoriginal)el"https://nhentai.comB=��������ZnHentai.com (unoriginal)ko"https://nhentai.comB=�ٮ�����rnHentai.com (unoriginal)ro"https://nhentai.com
�
NHentai.xxx,eu.kanade.tachiyomi.extension.all.nhentaixxx�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentaixxx-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaixxx.png"1.4(	21.4.98B0�����NHentai.xxxen"https://nhentai.xxxB0���靶RNHentai.xxxja"https://nhentai.xxxB0���È���NHentai.xxxzh"https://nhentai.xxxB1���ܗ�܋!NHentai.xxxall"https://nhentai.xxx
�
Niadd'eu.kanade.tachiyomi.extension.all.niadd�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.niadd-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.niadd.png"1.4(21.4.28B.Т�����iNiaddpt-BR"https://br.niadd.comB,��������VNiadden"https://www.niadd.comB+ʙԝ�ǁNiaddes"https://es.niadd.comB+���䍖�rNiaddit"https://it.niadd.comB+�賃����Niaddru"https://ru.niadd.comB+㫞�����.Niaddde"https://de.niadd.comB+�ژ�����(Niaddfr"https://fr.niadd.com
�
	NovelCool+eu.kanade.tachiyomi.extension.all.novelcool�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.novelcool-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.novelcool.png"1.4(21.4.88B4���Įᙇi	NovelCoolen"https://www.novelcool.comB3�є���׊	NovelCooles"https://es.novelcool.comB3��������B	NovelCoolde"https://de.novelcool.comB3��������	NovelCoolru"https://ru.novelcool.comB3��������	NovelCoolit"https://it.novelcool.comB6�������!	NovelCoolpt-BR"https://br.novelcool.comB3�􂋋��	NovelCoolfr"https://fr.novelcool.com
�
One Piece Fans.eu.kanade.tachiyomi.extension.all.onepiecefans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.onepiecefans-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.onepiecefans.png"1.4(21.4.18B;꯷�汩�)One Piece Fanses"https://one-piece-fans2.comB;��҄˒��[One Piece Fansen"https://one-piece-fans2.com
�
OniSaga)eu.kanade.tachiyomi.extension.all.onisaga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.onisaga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.onisaga.png"1.4(21.4.18B-����ϥ��wOniSagaall"https://onisaga.comB,���Ο���$OniSagaen"https://onisaga.comB,��𮈸��KOniSagafr"https://onisaga.comB,�����HOniSagaja"https://onisaga.comB/Փ���۞�JOniSagapt-BR"https://onisaga.comB,����Ѝ�4OniSagapt"https://onisaga.comB0؝ۙ����QOniSagaes-419"https://onisaga.comB,�����}OniSagaes"https://onisaga.com
�
OSOSEDKI*eu.kanade.tachiyomi.extension.all.ososedki�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ososedki-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ososedki.png"1.4(21.4.18B/͎�ɖ���	OSOSEDKIall"https://ososedki.com
�
PandaChaika-eu.kanade.tachiyomi.extension.all.pandachaika�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pandachaika-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pandachaika.png"1.4(21.4.48B6��ܵ����qPandaChaikaall"https://panda.chaika.moeB5��������1PandaChaikaen"https://panda.chaika.moeB5�������cPandaChaikazh"https://panda.chaika.moeB5�ϧ���ȢfPandaChaikako"https://panda.chaika.moeB5�����õ�PandaChaikaes"https://panda.chaika.moeB5�ɰ�����HPandaChaikaru"https://panda.chaika.moeB5��������PandaChaikapt"https://panda.chaika.moeB5��󤇥��jPandaChaikafr"https://panda.chaika.moeB5��������PandaChaikath"https://panda.chaika.moeB5�����ѽ&PandaChaikavi"https://panda.chaika.moeB5̫�����0PandaChaikaja"https://panda.chaika.moeB5��������#PandaChaikaid"https://panda.chaika.moeB5���஫��_PandaChaikaar"https://panda.chaika.moeB5��ˈ����PandaChaikauk"https://panda.chaika.moeB5����ʻ��^PandaChaikatr"https://panda.chaika.moeB5�ϕ���APandaChaikacs"https://panda.chaika.moeB5������`PandaChaikatl"https://panda.chaika.moeB5������כJPandaChaikafi"https://panda.chaika.moeB5����׷��KPandaChaikajv"https://panda.chaika.moeB5��˖����zPandaChaikael"https://panda.chaika.moe
�
Pepper&Carrot.eu.kanade.tachiyomi.extension.all.peppercarrot�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.peppercarrot-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.peppercarrot.png"1.4(21.4.58B<��Ĩ�Í�Pepper&Carrotall"https://www.peppercarrot.com
�
Photos18*eu.kanade.tachiyomi.extension.all.photos18�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.photos18-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.photos18.png"1.4(21.4.68B3��������Photos18all"https://www.photos18.com
�
Pixiv'eu.kanade.tachiyomi.extension.all.pixiv�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pixiv-v1.4.12.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pixiv.png"1.4(21.4.128B,ކ���ŧ�DPixiven"https://www.pixiv.netB,����ÿ��Pixivja"https://www.pixiv.netB,��Ǜ�ೞ`Pixivzh"https://www.pixiv.netB/���ǚ�kPixivzh-tw"https://www.pixiv.netB,������эGPixivko"https://www.pixiv.net
�
Playmate Hunter0eu.kanade.tachiyomi.extension.all.playmatehunter�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.playmatehunter-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.playmatehunter.png"1.4(21.4.28B9ű���͐�Playmate Hunterall"https://pmatehunter.com
�
PornPics*eu.kanade.tachiyomi.extension.all.pornpics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pornpics-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pornpics.png"1.4(21.4.38B2��ȷ���PornPicsen"https://www.pornpics.comB2�¯���bPornPicszh"https://www.pornpics.com
�
Project Suki-eu.kanade.tachiyomi.extension.all.projectsuki�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.projectsuki-v1.4.8.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.projectsuki.png"1.4(21.4.88B7�����ն|Project Sukiall"https://projectsuki.com/
�

RokuHentai,eu.kanade.tachiyomi.extension.all.rokuhentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.rokuhentai-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.rokuhentai.png"1.4(21.4.18B4�����ۀ^Roku Hentaiall"https://rokuhentai.com
�
BlossomManhwa.eu.kanade.tachiyomi.extension.all.sakuramanhwa�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.sakuramanhwa-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sakuramanhwa.png"1.4(21.4.58B<��ڄ���BlossomManhwaall"https://api.cherrymanhwa.com
�
Sandra and Woo.eu.kanade.tachiyomi.extension.all.sandraandwoo�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.sandraandwoo-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sandraandwoo.png"1.4(21.4.38B<�ո�����pSandra und Woode"https://www.sandraandwoo.comB<�������vSandra and Wooen"https://www.sandraandwoo.com
�
SeraphicDeviltry2eu.kanade.tachiyomi.extension.all.seraphicdeviltry�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.seraphicdeviltry-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.seraphicdeviltry.png"1.4(521.4.538B?Ҫ�����JSeraphicDeviltryen"https://seraphic-deviltry.comBG�����ӫ�[SeraphicDeviltryes"%https://spanish.seraphic-deviltry.com
�
Simply Cosplay/eu.kanade.tachiyomi.extension.all.simplycosplay�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.simplycosplay-v1.4.4.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplycosplay.png"1.4(21.4.48B?��������LSimply Cosplayall"https://www.simply-cosplay.com
�
Simply Hentai.eu.kanade.tachiyomi.extension.all.simplyhentai�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.simplyhentai-v1.4.8.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplyhentai.png"1.4(21.4.88B<׽���恓Simply Hentaien"https://www.simply-hentai.comB<��������
Simply Hentaija"https://www.simply-hentai.comB<��ɤ���XSimply Hentaizh"https://www.simply-hentai.comB<���ש���KSimply Hentaiko"https://www.simply-hentai.comB<ݪ���̔�	Simply Hentaies"https://www.simply-hentai.comB<�����̔�RSimply Hentairu"https://www.simply-hentai.comB<��݇܏��=Simply Hentaifr"https://www.simply-hentai.comB<ߝʑܗ��PSimply Hentaide"https://www.simply-hentai.comB<���ΰ���~Simply Hentaiit"https://www.simply-hentai.comB<ʣ������%Simply Hentaipl"https://www.simply-hentai.com
�
StashApp*eu.kanade.tachiyomi.extension.all.stashapp�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.stashapp-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.stashapp.png"1.4(21.4.18B0������ߐ<StashAppall"http://localhost:9999
�
Taddy INK (Webtoons)*eu.kanade.tachiyomi.extension.all.taddyink�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.taddyink-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.taddyink.png"1.4(21.4.38B8���Ӆ� Taddy INK (Webtoons)all"https://taddy.org
�
	Tappytoon+eu.kanade.tachiyomi.extension.all.tappytoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.tappytoon-v1.4.10.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.tappytoon.png"1.4(
21.4.108B7�������a	Tappytoonen"https://www.tappytoon.com/enB7������٫s	Tappytoonfr"https://www.tappytoon.com/frB7�ҵŎ���x	Tappytoonde"https://www.tappytoon.com/de
�
The Library of Ohara3eu.kanade.tachiyomi.extension.all.thelibraryofohara�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.thelibraryofohara-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thelibraryofohara.png"1.4(21.4.28BC�É�����<The Library of Oharaid"https://thelibraryofohara.comBCɵ������%The Library of Oharaen"https://thelibraryofohara.comBC��ͨ��́The Library of Oharaes"https://thelibraryofohara.comBC��ϥ����The Library of Oharait"https://thelibraryofohara.comBC�߹�����qThe Library of Oharaar"https://thelibraryofohara.comBC����񉵘dThe Library of Oharafr"https://thelibraryofohara.com
�
Thunder Scans.eu.kanade.tachiyomi.extension.all.thunderscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.thunderscans-v1.4.45.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thunderscans.png"1.4(-21.4.458B1��������,
Lava Scansar"https://lavascans.comB:܆Ζ����'Thunder Scansen"https://en-thunderscans.com
�
Toomics)eu.kanade.tachiyomi.extension.all.toomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.toomics-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.toomics.png"1.4(
21.4.108BH������њaToomics (Only free chapters)en"https://global.toomics.comBM�㶘���Toomics (Only free chapters)zh-Hans"https://global.toomics.comBM��������Toomics (Only free chapters)zh-Hant"https://global.toomics.comBL����󊙖fToomics (Only free chapters)es-419"https://global.toomics.comBH�����ӿCToomics (Only free chapters)es"https://global.toomics.comBH�������jToomics (Only free chapters)it"https://global.toomics.comBHɣ�㑁��:Toomics (Only free chapters)de"https://global.toomics.comBH�����Toomics (Only free chapters)fr"https://global.toomics.comBK����麖�>Toomics (Only free chapters)pt-BR"https://global.toomics.com
�
Twicomi)eu.kanade.tachiyomi.extension.all.twicomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.twicomi-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.twicomi.png"1.4(21.4.18B-�������?Twicomiall"https://twicomi.com
�
Uncensored Manhwa2eu.kanade.tachiyomi.extension.all.uncensoredmanhwa�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.uncensoredmanhwa-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.uncensoredmanhwa.png"1.4(321.4.518B>󾜳�̠�Uncensored Manhwaen"https://uncensoredmanhwa.usB?�٥��Ш�rUncensored Manhwaall"https://uncensoredmanhwa.us
�
V2PH&eu.kanade.tachiyomi.extension.all.v2ph�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.v2ph-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.v2ph.png"1.4(21.4.18B+γ������>V2PHall"https://www.v2ph.com
�
Vinne Veritas - CCC/eu.kanade.tachiyomi.extension.all.vinnieVeritas�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.vinnieVeritas-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.vinnieVeritas.png"1.4(21.4.38BCު������|Vinnie Veritas - CCCen"https://ccc.vinnieveritas.comBC����ԟ�Vinnie Veritas - CCCes"https://ccc.vinnieveritas.com
�
Webtoons.com*eu.kanade.tachiyomi.extension.all.webtoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.webtoons-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.webtoons.png"1.4(721.4.558B6ر����Ȁ#Webtoons.comen"https://www.webtoons.comB6ʮŮ�yWebtoons.comid"https://www.webtoons.comB6����ϔ�.Webtoons.comth"https://www.webtoons.comB6��҈��ԟxWebtoons.comes"https://www.webtoons.comB6��ҩ�͈�rWebtoons.comfr"https://www.webtoons.comB;��ӗ����)Webtoons.comzh-Hant"https://www.webtoons.comB6��������Webtoons.comde"https://www.webtoons.com
�
XArt Hunter,eu.kanade.tachiyomi.extension.all.xarthunter�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xarthunter-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xarthunter.png"1.4(21.4.28B8��џ�殆gXArt Hunterall"https://www.xarthunter.com
�
Xasiat Albums.eu.kanade.tachiyomi.extension.all.xasiatalbums�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xasiatalbums-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xasiatalbums.png"1.4(21.4.38B6�����cXAsiat Albumsall"https://www.xasiat.com
�
XGMN&eu.kanade.tachiyomi.extension.all.xgmn�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xgmn-v1.4.3.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xgmn.png"1.4(21.4.38B/����Ǩ�'性感美女all"http://xgmn8.vip
�

Xinmeitulu,eu.kanade.tachiyomi.extension.all.xinmeitulu�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xinmeitulu-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xinmeitulu.png"1.4(21.4.78B7��к���i
Xinmeituluall"https://www.xinmeitulu.com
�
Xiutaku)eu.kanade.tachiyomi.extension.all.xiutaku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xiutaku-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xiutaku.png"1.4(21.4.48B-���֝��ZXiutakuall"https://xiutaku.com
�
xkcd&eu.kanade.tachiyomi.extension.all.xkcd�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xkcd-v1.4.16.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xkcd.png"1.4(21.4.168B&��������xkcden"https://xkcd.comB)�����ʼ�_xkcdes"https://es.xkcd.comB%�Φ��ڊ�qxkcdzh"https://xkcd.twB,���ּ���xkcdfr"https://xkcd.lapin.orgB%��������3xkcdru"https://xkcd.ru
�
Yabai'eu.kanade.tachiyomi.extension.all.yabai�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yabai-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yabai.png"1.4(21.4.38B(��͇����Yabaiall"https://yabai.si
�
Yaoi Manga Online1eu.kanade.tachiyomi.extension.all.yaoimangaonline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yaoimangaonline-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yaoimangaonline.png"1.4(21.4.58B?������nYaoi Manga Onlineall"https://yaoimangaonline.com
�

YellowNote,eu.kanade.tachiyomi.extension.all.yellownote�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yellownote-v1.4.6.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yellownote.png"1.4(21.4.68B0�è�����	小黄书all"https://en.xchina.co
�

YSK Comics+eu.kanade.tachiyomi.extension.all.yskcomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yskcomics-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yskcomics.png"1.4(21.4.18B6������
YSK Comicsar"https://www.ysk-comics.comB6�ְч���
YSK Comicsen"https://www.ysk-comics.com
�

Akai Comic*eu.kanade.tachiyomi.extension.en.akaicomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.akaicomic-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.akaicomic.png"1.4(21.4.38B1��ۖ���
Akai Comicen"https://akaicomic.org
�
Alandal(eu.kanade.tachiyomi.extension.en.alandal�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.alandal-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.alandal.png"1.4(21.4.28B,��Ƈ�ɕ�Alandalen"https://alandal.com
�
AllManga)eu.kanade.tachiyomi.extension.en.allanime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allanime-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allanime.png"1.4(21.4.198B-��ظֹ��AAllMangaen"https://allmanga.to
�
AllPornComic-eu.kanade.tachiyomi.extension.en.allporncomic�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allporncomic-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomic.png"1.4(521.4.538B6��������vAllPornComicen"https://allporncomic.com
�
AllPornComic.io/eu.kanade.tachiyomi.extension.en.allporncomicio�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allporncomicio-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomicio.png"1.4(321.4.518B8�ѹ�����\AllPornComic.ioen"https://allporncomic.io
�
Anisa Scans+eu.kanade.tachiyomi.extension.en.anisascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.anisascans-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.anisascans.png"1.4(421.4.528B2Յ���Î�{Anisa Scansen"https://anisascans.in
�
	AP Comics)eu.kanade.tachiyomi.extension.en.apcomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.apcomics-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.apcomics.png"1.4(321.4.518B/���ѵ���l	AP Comicsen"https://apcomics.org
�

Aqua Manga*eu.kanade.tachiyomi.extension.en.aquamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aquamanga-v1.4.62.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aquamanga.png"1.4(>21.4.628B2������
Aqua Mangaen"https://aquareader.org
�
Arc-Relight+eu.kanade.tachiyomi.extension.en.arcrelight�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arcrelight-v1.4.15.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arcrelight.png"1.4(21.4.158B4�����ƙ�^Arc-Relighten"https://arc-relight.com
�
Arena Scans+eu.kanade.tachiyomi.extension.en.arenascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arenascans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arenascans.png"1.4( 21.4.328B2����ٽ��zArena Scansen"https://arenascan.com
�

Armageddon+eu.kanade.tachiyomi.extension.en.armageddon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.armageddon-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.armageddon.png"1.4("21.4.348B7���Ꭹ��
Armageddonen"https://www.silentquill.net
�
	Art Lapsa)eu.kanade.tachiyomi.extension.en.artlapsa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.artlapsa-v1.4.25.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.artlapsa.png"1.4(21.4.258B/�����Ș
	Art Lapsaen"https://artlapsa.com
�
Vortex Scans+eu.kanade.tachiyomi.extension.en.arvenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arvenscans-v1.4.61.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arvenscans.png"1.4(=21.4.618B5��������#Vortex Scansen"https://vortexscans.org
�

Arya Scans*eu.kanade.tachiyomi.extension.en.aryascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aryascans-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aryascans.png"1.4(421.4.528B6˲������i
Arya Scansen"https://brainrotcomics.com
�
AsiaToon)eu.kanade.tachiyomi.extension.en.asiatoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asiatoon-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asiatoon.png"1.4(21.4.18B.��ݬ��vAsiaToonen"https://asiatoon.net
�
Asmodeus Scans)eu.kanade.tachiyomi.extension.en.asmotoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asmotoon-v1.4.22.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asmotoon.png"1.4(21.4.228B4����ж��HAsmodeus Scansen"https://asmotoon.com
�
Assorted Scans.eu.kanade.tachiyomi.extension.en.assortedscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.assortedscans-v1.4.17.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.assortedscans.png"1.4(21.4.178B9��������pAssorted Scansen"https://assortedscans.com
�
Asura Scans+eu.kanade.tachiyomi.extension.en.asurascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asurascans-v1.4.62.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asurascans.png"1.4(>21.4.628B3�������VAsura Scansen"https://asurascans.com
�
Athrea Scans,eu.kanade.tachiyomi.extension.en.athreascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.athreascans-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.athreascans.png"1.4(!21.4.338B5�㠏����Athrea Scansen"https://athreascans.com
�
Atsumaru)eu.kanade.tachiyomi.extension.en.atsumaru�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.atsumaru-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.atsumaru.png"1.4(21.4.198B*�à�� Atsumaruen"https://atsu.moe
�
aurora'eu.kanade.tachiyomi.extension.en.aurora�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aurora-v1.4.4.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aurora.png"1.4(21.4.48B/��ܤӚ��~Auroraen"https://comicaurora.com
�
Omoi&eu.kanade.tachiyomi.extension.en.azuki�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.azuki-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.azuki.png"1.4(21.4.28B*��¼���qOmoien"https://www.omoi.com
�
Bakkin'eu.kanade.tachiyomi.extension.en.bakkin�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bakkin-v1.4.7.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkin.png"1.4(21.4.78B2ߵ�߷���Bakkinen"https://bakkin.moe/reader/
�
Bakkin Self-hosted1eu.kanade.tachiyomi.extension.en.bakkinselfhosted�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bakkinselfhosted-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkinselfhosted.png"1.4(21.4.78B5��������VBakkin Self-hosteden"http://127.0.0.1/
�
BatCave(eu.kanade.tachiyomi.extension.en.batcave�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.batcave-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.batcave.png"1.4(21.4.68B,����񄦀gBatCaveen"https://batcave.biz
�
!Battle In 5 Seconds After Meeting@eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.battleinfivesecondsaftermeeting-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting.png"1.4(321.4.518BJ�犋����#!Battle In 5 Seconds After Meetingen"https://www.deatte5.com
�
Bbato&eu.kanade.tachiyomi.extension.en.bbato�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bbato-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bbato.png"1.4(21.4.18B(����Ϡ��Bbatoen"https://bbato.com
�
	BeeHentai*eu.kanade.tachiyomi.extension.en.beehentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.beehentai-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.beehentai.png"1.4(21.4.248B0�����ٖ�5	BeeHentaien"https://beehentai.com
�

BookWalker+eu.kanade.tachiyomi.extension.en.bookwalker�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bookwalker-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bookwalker.png"1.4(21.4.78B2������&
BookWalkeren"https://bookwalker.com
�
Borat Scans+eu.kanade.tachiyomi.extension.en.boratscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.boratscans-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.boratscans.png"1.4(321.4.518B3�������mBorat Scansen"https://boratscans.com
�
Broccoli Soup-eu.kanade.tachiyomi.extension.en.broccolisoup�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.broccolisoup-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.broccolisoup.png"1.4(21.4.18B8�������Broccoli Soupen"https://politeandgood.com
�
	Bun Manga)eu.kanade.tachiyomi.extension.en.bunmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bunmanga-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bunmanga.png"1.4(321.4.518B/���ڒ��R	Bun Mangaen"https://bunmanga.com
�

buttsmithy+eu.kanade.tachiyomi.extension.en.buttsmithy�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.buttsmithy-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.buttsmithy.png"1.4(21.4.48B9������G
Buttsmithyen"https://incase.buttsmithy.com
�
Clone Manga+eu.kanade.tachiyomi.extension.en.clonemanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.clonemanga-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clonemanga.png"1.4(21.4.38B9��������OClone Mangaen"https://manga.clone-army.org
�
Clown Corps+eu.kanade.tachiyomi.extension.en.clowncorps�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.clowncorps-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clowncorps.png"1.4(21.4.38B3��������Clown Corpsen"https://clowncorps.net
�
CManhua(eu.kanade.tachiyomi.extension.en.cmanhua�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cmanhua-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cmanhua.png"1.4(21.4.18B,�ݯ�����qCManhuaen"https://cmanhua.com
�
Cocomic(eu.kanade.tachiyomi.extension.en.cocomic�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cocomic-v1.4.53.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cocomic.png"1.4(521.4.538B+���߸���1Cocomicen"https://cocomic.co
�
Coffee Manga,eu.kanade.tachiyomi.extension.en.coffeemanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.coffeemanga-v1.4.56.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.coffeemanga.png"1.4(821.4.568B5��ʫ����iCoffee Mangaen"https://coffeemanga.ink
�
Collected Curios0eu.kanade.tachiyomi.extension.en.collectedcurios�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.collectedcurios-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.collectedcurios.png"1.4(21.4.28BAܛ����ިCollected Curiosen"https://www.collectedcurios.com
�
Comic Asura+eu.kanade.tachiyomi.extension.en.comicasura�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicasura-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicasura.png"1.4("21.4.348B3�;����Comic Asuraen"https://comicasura.net
�
Comic CX(eu.kanade.tachiyomi.extension.en.comiccx�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comiccx-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comiccx.png"1.4(21.4.18B*÷������Comic CXen"https://comic.cx
�
ComicHubFree-eu.kanade.tachiyomi.extension.en.comichubfree�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comichubfree-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comichubfree.png"1.4(21.4.38B6巵����� ComicHubFreeen"https://comichubfree.com
�
ComicK Fanmade*eu.kanade.tachiyomi.extension.en.comickfan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comickfan-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comickfan.png"1.4(21.4.38B5�팏̺��ComicK Fanmadeen"https://comickfan.com
�
	ComicLand*eu.kanade.tachiyomi.extension.en.comicland�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicland-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicland.png"1.4(21.4.18B0��������X	ComicLanden"https://comicland.org
�
Comics Land+eu.kanade.tachiyomi.extension.en.comicsland�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicsland-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicsland.png"1.4( 21.4.328B3�����ȃ� Comics Landen"https://comicsland.org
�
Comix&eu.kanade.tachiyomi.extension.en.comix�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comix-v1.4.31.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comix.png"1.4(21.4.318B'���牆��hComixen"https://comix.to
�
Coolmic(eu.kanade.tachiyomi.extension.en.coolmic�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.coolmic-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.coolmic.png"1.4(21.4.28B+�����͡ICoolmicen"https://coolmic.me
�

Crow Scans*eu.kanade.tachiyomi.extension.en.crowscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.crowscans-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.crowscans.png"1.4( 21.4.328B1����ɓ��
Crow Scansen"https://crowscans.xyz
�
Cucumber Manga.eu.kanade.tachiyomi.extension.en.cucumbermanga�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cucumbermanga-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cucumbermanga.png"1.4(321.4.518B9�������5Cucumber Mangaen"https://cucumbermanga.com
�
CulturedWorks.eu.kanade.tachiyomi.extension.en.culturedworks�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.culturedworks-v1.4.33.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.culturedworks.png"1.4(!21.4.338B8����Ę�CulturedWorksen"https://culturedworks.com
�
Cutie Comics,eu.kanade.tachiyomi.extension.en.cutiecomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cutiecomics-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cutiecomics.png"1.4(21.4.58B5��ٲ����lCutie Comicsen"https://cutiecomics.com
�
Danke fürs Lesen/eu.kanade.tachiyomi.extension.en.dankefurslesen�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dankefurslesen-v1.4.7.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dankefurslesen.png"1.4(21.4.78B4�������Danke fürs Lesenen"https://danke.moe
�
Dark Legacy Comics1eu.kanade.tachiyomi.extension.en.darklegacycomics�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darklegacycomics-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darklegacycomics.png"1.4(21.4.18BD����ǲ��Dark Legacy Comicsen" https://www.darklegacycomics.com
�
Dark Science,eu.kanade.tachiyomi.extension.en.darkscience�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darkscience-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darkscience.png"1.4(21.4.18B6��������Dark Scienceen"https://dresdencodak.com
�
Darths & Droids-eu.kanade.tachiyomi.extension.en.darthsdroids�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darthsdroids-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darthsdroids.png"1.4(21.4.28B@�����뒮Darths & Droidsen"https://www.darthsanddroids.net
�
Death Toll Scans/eu.kanade.tachiyomi.extension.en.deathtollscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.deathtollscans-v1.4.5.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.deathtollscans.png"1.4(21.4.58BC���Ʈ���ADeath Toll Scansen"!https://reader.deathtollscans.net
�
Decadence Scans/eu.kanade.tachiyomi.extension.en.decadencescans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.decadencescans-v1.4.53.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.decadencescans.png"1.4(521.4.538BB�ҿ��gDecadence Scansen"!https://reader.decadencescans.com
�

DFlowScans+eu.kanade.tachiyomi.extension.en.dflowscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dflowscans-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dflowscans.png"1.4(21.4.18B8�怗����O
DFlowScansen"https://dflow.alwaysdata.net
�
Digital Comic Museum3eu.kanade.tachiyomi.extension.en.digitalcomicmuseum�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.digitalcomicmuseum-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.digitalcomicmuseum.png"1.4(21.4.48BD��­���Digital Comic Museumen"https://digitalcomicmuseum.com
�

Diva Scans*eu.kanade.tachiyomi.extension.en.divascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.divascans-v1.4.25.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.divascans.png"1.4(21.4.258B1���Ѻ�ÉL
Diva Scansen"https://divascans.org
�
Doujin.io - J18)eu.kanade.tachiyomi.extension.en.doujinio�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.doujinio-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujinio.png"1.4(21.4.38B2ʰ�����&Doujin.io - J18en"https://doujin.io
�
Doujins(eu.kanade.tachiyomi.extension.en.doujins�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.doujins-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujins.png"1.4(21.4.68B,��ʀ����3Doujinsen"https://doujins.com
�
	DragonTea*eu.kanade.tachiyomi.extension.en.dragontea�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dragontea-v1.4.56.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dragontea.png"1.4(821.4.568B0�贙���[	DragonTeaen"https://dragontea.ink
�
Drake Scans+eu.kanade.tachiyomi.extension.en.drakescans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.drakescans-v1.4.48.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.drakescans.png"1.4(021.4.488B3��ă����rDrake Scansen"https://drakecomic.org
�
Dynasty(eu.kanade.tachiyomi.extension.en.dynasty�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dynasty-v1.4.30.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dynasty.png"1.4(21.4.308B8���ۡ�Ƥ	Dynasty Scansen"https://dynasty-scans.com
�
Eggporncomics.eu.kanade.tachiyomi.extension.en.eggporncomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eggporncomics-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eggporncomics.png"1.4(21.4.38B8��ۗꐗ�dEggporncomicsen"https://eggporncomics.com
�
El Goonish Shive*eu.kanade.tachiyomi.extension.en.egscomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.egscomics-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.egscomics.png"1.4(21.4.28B;�����\El Goonish Shiveen"https://www.egscomics.com
�
18 Porn Comic2eu.kanade.tachiyomi.extension.en.eighteenporncomic�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eighteenporncomic-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eighteenporncomic.png"1.4(21.4.38B6��͎����G18 Porn Comicen"https://18porncomic.com
�
8Muses+eu.kanade.tachiyomi.extension.en.eightmuses�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eightmuses-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eightmuses.png"1.4(21.4.28B1������8Musesen"https://comics.8muses.com
�
Elan School+eu.kanade.tachiyomi.extension.en.elanschool�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.elanschool-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elanschool.png"1.4(21.4.18B0����郔�UElan Schoolen"https://elan.school
�
Elf Toon(eu.kanade.tachiyomi.extension.en.elftoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.elftoon-v1.4.34.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elftoon.png"1.4("21.4.348B-��������6Elf Toonen"https://elftoon.com
�
emaqi&eu.kanade.tachiyomi.extension.en.emaqi�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.emaqi-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.emaqi.png"1.4(21.4.18B(��������.emaqien"https://emaqi.com
�
	EpicManga*eu.kanade.tachiyomi.extension.en.epicmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.epicmanga-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.epicmanga.png"1.4(321.4.518B/𖿊��Σo	EpicMangaen"https://epicmanga.co
�

Eris Scans*eu.kanade.tachiyomi.extension.en.erisscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erisscans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erisscans.png"1.4(21.4.208B1��̴����s
Eris Scansen"https://erisscans.com
�
Ero18x'eu.kanade.tachiyomi.extension.en.ero18x�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ero18x-v1.4.51.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ero18x.png"1.4(321.4.518B*����۱�QEro18xen"https://ero18x.com
�
Erofus'eu.kanade.tachiyomi.extension.en.erofus�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erofus-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erofus.png"1.4(21.4.38B.ȴ����߲*Erofusen"https://www.erofus.com
�
Scythe Scans*eu.kanade.tachiyomi.extension.en.erosscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erosscans-v1.4.39.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erosscans.png"1.4('21.4.398B5�������Scythe Scansen"https://scythescans.com
�
	Eva Scans)eu.kanade.tachiyomi.extension.en.evascans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.evascans-v1.4.34.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.evascans.png"1.4("21.4.348B/�Γ�����	Eva Scansen"https://evascans.org
�
Existential Comics2eu.kanade.tachiyomi.extension.en.existentialcomics�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.existentialcomics-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.existentialcomics.png"1.4(21.4.58BA�޶�����	Existential Comicsen"https://existentialcomics.com
�
Cyanide & Happiness(eu.kanade.tachiyomi.extension.en.explosm�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.explosm-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.explosm.png"1.4(21.4.58B8��������Cyanide & Happinessen"https://explosm.net
�
EZmanga(eu.kanade.tachiyomi.extension.en.ezmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ezmanga-v1.4.62.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ezmanga.png"1.4(>21.4.628B,�،�ĵ�.EZmangaen"https://ezmanga.org
�
Fable Scans+eu.kanade.tachiyomi.extension.en.fablescans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.fablescans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fablescans.png"1.4( 21.4.328B3�̤���CFable Scansen"https://fablescans.com
�
Fairy Scans+eu.kanade.tachiyomi.extension.en.fairyscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.fairyscans-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fairyscans.png"1.4(!21.4.338B3����ȣ��lFairy Scansen"https://fairyscans.com
�
	Firescans*eu.kanade.tachiyomi.extension.en.firescans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.firescans-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.firescans.png"1.4(721.4.558B0�Ğ��ܴ�O	Firescansen"https://firescans.xyz
�
Flame Comics,eu.kanade.tachiyomi.extension.en.flamecomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.flamecomics-v1.4.49.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.flamecomics.png"1.4(121.4.498B5����욈�vFlame Comicsen"https://flamecomics.xyz
�
Frieren Online.eu.kanade.tachiyomi.extension.en.frierenonline�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.frierenonline-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.frierenonline.png"1.4(321.4.518B9���ȹ��1Frieren Onlineen"https://www.frieren.online
�

GakaMangas+eu.kanade.tachiyomi.extension.en.gakamangas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gakamangas-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gakamangas.png"1.4(321.4.518B2�������H
GakaMangasen"https://gakamangas.com
�
GalaxyDegenScans1eu.kanade.tachiyomi.extension.en.galaxydegenscans�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.galaxydegenscans-v1.4.55.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxydegenscans.png"1.4(721.4.558B5�Ͱ����?GalaxyDegenScansen"https://gdscans.com
�
Galaxy Manga,eu.kanade.tachiyomi.extension.en.galaxymanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.galaxymanga-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxymanga.png"1.4( 21.4.328B4؜������*Galaxy Mangaen"https://galaxymanga.io
�

GEDE Comix*eu.kanade.tachiyomi.extension.en.gedecomix�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gedecomix-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gedecomix.png"1.4(321.4.518B1�מ�����6
GEDE Comixen"https://gedecomix.com
�

GingeRTooN+eu.kanade.tachiyomi.extension.en.gingertoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gingertoon-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gingertoon.png"1.4(321.4.518B2��Ś���:
GingeRTooNen"https://gingertoon.com
�
GirlsTop)eu.kanade.tachiyomi.extension.en.girlstop�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.girlstop-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.girlstop.png"1.4(21.4.18B2�����ǟ�GirlsTopen"https://en.girlstop.info
�
Goda%eu.kanade.tachiyomi.extension.en.goda�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.goda-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.goda.png"1.4(21.4.38B-⏣�����;Godaen"https://manhuascans.org
�
Gourmet Scans-eu.kanade.tachiyomi.extension.en.gourmetscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gourmetscans-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gourmetscans.png"1.4(321.4.518B;��갲�ģ3Gourmet Scansen"https://gourmetsupremacy.com
�
Greed Scans+eu.kanade.tachiyomi.extension.en.greedscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.greedscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.greedscans.png"1.4( 21.4.328B2������Greed Scansen"https://gojoscans.com
�

Grim Scans*eu.kanade.tachiyomi.extension.en.grimscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.grimscans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grimscans.png"1.4(21.4.208B1������Șw
Grim Scansen"https://grimscans.com
�
Grrl Power Comic*eu.kanade.tachiyomi.extension.en.grrlpower�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.grrlpower-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grrlpower.png"1.4(21.4.48B@��ښ����Grrl Power Comicen"https://www.grrlpowercomic.com
�
Gunnerkrigg Court1eu.kanade.tachiyomi.extension.en.gunnerkriggcourt�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gunnerkriggcourt-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gunnerkriggcourt.png"1.4(21.4.38B>��ֆ����SGunnerkrigg Courten"https://www.gunnerkrigg.com
�
Guya%eu.kanade.tachiyomi.extension.en.guya�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.guya-v1.4.25.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.guya.png"1.4(21.4.258B-������خ@Guyaen"https://guya.cubari.moe
�
Gone with the Blastwave%eu.kanade.tachiyomi.extension.en.gwtb�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gwtb-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gwtb.png"1.4(21.4.38BH܃߃����7Gone with the Blastwaveen"https://www.blastwave-comic.com
�
	Hachirumi*eu.kanade.tachiyomi.extension.en.hachirumi�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hachirumi-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hachirumi.png"1.4(21.4.78B0�������	Hachirumien"https://hachirumi.com
�
Hades Scans+eu.kanade.tachiyomi.extension.en.hadesscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hadesscans-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hadesscans.png"1.4(!21.4.338B3����Ɣ�<Hades Scansen"https://hadesscans.com
�
Hentai3z.CC+eu.kanade.tachiyomi.extension.en.hentai3zcc�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai3zcc-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai3zcc.png"1.4(21.4.38B0樳����Hentai3z.CCen"https://hentai3z.cc
�
Hentai4Free,eu.kanade.tachiyomi.extension.en.hentai4free�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai4free-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai4free.png"1.4(321.4.518B4�쒢����[Hentai4Freeen"https://hentai4free.net
�
	HentaiDex*eu.kanade.tachiyomi.extension.en.hentaidex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaidex-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaidex.png"1.4("21.4.348B0��������	HentaiDexen"https://dexhentai.com
�

HentaiHere+eu.kanade.tachiyomi.extension.en.hentaihere�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaihere-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaihere.png"1.4(21.4.78B2���Ŕ���d
HentaiHereen"https://hentaihere.com
�

HentaiKisu+eu.kanade.tachiyomi.extension.en.hentaikisu�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaikisu-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaikisu.png"1.4(21.4.18B2Ǝ�Ӵ��J
HentaiKisuen"https://hentaikisu.com
�
	HentaiKun*eu.kanade.tachiyomi.extension.en.hentaikun�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaikun-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaikun.png"1.4(21.4.18B0�ׂ쿸�!	HentaiKunen"https://hentaikun.com
�
HentaiNexus,eu.kanade.tachiyomi.extension.en.hentainexus�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentainexus-v1.4.18.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentainexus.png"1.4(21.4.188B4��������kHentaiNexusen"https://hentainexus.com
�

HentaiRead+eu.kanade.tachiyomi.extension.en.hentairead�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentairead-v1.4.61.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentairead.png"1.4(=21.4.618B2��ࡲ���
HentaiReaden"https://hentairead.com
�
HentaiRead.io-eu.kanade.tachiyomi.extension.en.hentaireadio�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaireadio-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaireadio.png"1.4(21.4.18B4���䫙��HentaiRead.ioen"https://hentairead.io
�
	HentaiSco*eu.kanade.tachiyomi.extension.en.hentaisco�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaisco-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaisco.png"1.4(321.4.518B/֎ܯ���]	HentaiScoen"https://hentaisco.cc
�
HentaiXComic-eu.kanade.tachiyomi.extension.en.hentaixcomic�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixcomic-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixcomic.png"1.4(321.4.518B6�����ƮjHentaiXComicen"https://hentaixcomic.com
�
HentaiXDickgirl0eu.kanade.tachiyomi.extension.en.hentaixdickgirl�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixdickgirl-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixdickgirl.png"1.4(321.4.518B<�Ǖ�����HentaiXDickgirlen"https://hentaixdickgirl.com
�
HentaiXYuri,eu.kanade.tachiyomi.extension.en.hentaixyuri�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixyuri-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixyuri.png"1.4(321.4.518B4��Ҟ�Х�HentaiXYurien"https://hentaixyuri.com
�
Hentara(eu.kanade.tachiyomi.extension.en.hentara�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentara-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentara.png"1.4(21.4.38B,倌��߰�aHentaraen"https://hentara.com
�
HeyToon(eu.kanade.tachiyomi.extension.en.heytoon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.heytoon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.heytoon.png"1.4(21.4.18B,�����ևHHeyToonen"https://heytoon.net
�
Hijala Scans,eu.kanade.tachiyomi.extension.en.hijalascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hijalascans-v1.4.23.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hijalascans.png"1.4(21.4.238B3�ԅ�����Hijala Scansen"https://en-hijala.com
�
Hiperdex)eu.kanade.tachiyomi.extension.en.hiperdex�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hiperdex-v1.4.80.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiperdex.png"1.4(P21.4.808B.�םό�*Hiperdexen"https://hiperdex.com
�
Hiveworks Comics*eu.kanade.tachiyomi.extension.en.hiveworks�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hiveworks-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiveworks.png"1.4(21.4.128B=���ݶ���[Hiveworks Comicsen"https://hiveworkscomics.com
�
HM2D%eu.kanade.tachiyomi.extension.en.hm2d�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hm2d-v1.4.53.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hm2d.png"1.4(521.4.538B0����՞��eHM2Den"https://doujindistrict.com
�
HonkaiImpact3-eu.kanade.tachiyomi.extension.en.honkaiimpact�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.honkaiimpact-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.honkaiimpact.png"1.4(21.4.48BB����ꌹNHonkai Impact 3rden"https://manga.honkaiimpact3.com
�
	HotComics*eu.kanade.tachiyomi.extension.en.hotcomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hotcomics-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hotcomics.png"1.4(21.4.28B/������W	HotComicsen"https://hotcomics.me
�
Hyakuro Translations(eu.kanade.tachiyomi.extension.en.hyakuro�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hyakuro-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hyakuro.png"1.4(21.4.18B9�������EHyakuro Translationsen"https://hyakuro.net
�
I,eu.kanade.tachiyomi.extension.en.imanevilgod�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.imanevilgod-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.imanevilgod.png"1.4(21.4.78B8�������kI'm An Evil Goden"https://imanevilgod.com
�

Hive Scans2eu.kanade.tachiyomi.extension.en.infernalvoidscans�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.infernalvoidscans-v1.4.65.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infernalvoidscans.png"1.4(A21.4.658B1��������W
Hive Scansen"https://hivetoons.org
�
InfinityScans.eu.kanade.tachiyomi.extension.en.infinityscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.infinityscans-v1.4.10.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infinityscans.png"1.4(
21.4.108B8�ջ����kInfinityScansen"https://infinityscans.org
�
I Roved Out*eu.kanade.tachiyomi.extension.en.irovedout�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.irovedout-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.irovedout.png"1.4(21.4.58B6��㗿���qI Roved Outen"https://www.irovedout.com
�
IsekaiScan.top (unoriginal).eu.kanade.tachiyomi.extension.en.isekaiscantop�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.isekaiscantop-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.isekaiscantop.png"1.4(421.4.528BC׆������'IsekaiScan.top (unoriginal)en"https://isekaiscan.top
�
	Jinmangas*eu.kanade.tachiyomi.extension.en.jinmangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.jinmangas-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jinmangas.png"1.4(321.4.518B0�������O	Jinmangasen"https://jinmangas.com
�
J-Novel'eu.kanade.tachiyomi.extension.en.jnovel�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.jnovel-v1.4.4.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jnovel.png"1.4(21.4.48B-������"J-Novelen"https://j-novel.club
�
Kaizen Scan+eu.kanade.tachiyomi.extension.en.kaizenscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaizenscan-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaizenscan.png"1.4(21.4.208B3��ƲŬ��Kaizen Scanen"https://kaizenscan.com
�
KaliScan,eu.kanade.tachiyomi.extension.en.kaliscancom�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaliscancom-v1.4.25.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaliscancom.png"1.4(21.4.258B.����ͱ��jKaliScanen"https://kaliscan.com
�
Kappa Beast+eu.kanade.tachiyomi.extension.en.kappabeast�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kappabeast-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kappabeast.png"1.4(!21.4.338B3����뾀�$Kappa Beasten"https://kappabeast.com
�

Kayn Scans*eu.kanade.tachiyomi.extension.en.kaynscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaynscans-v1.4.27.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaynscans.png"1.4(21.4.278B0�������/
Kayn Scansen"https://kaynscan.org
�
keenspot)eu.kanade.tachiyomi.extension.en.keenspot�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.keenspot-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.keenspot.png"1.4(21.4.38B@�休����+Keenspot TwoKindsen"https://twokinds.keenspot.com
�
	Ken Scans)eu.kanade.tachiyomi.extension.en.kenscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kenscans-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kenscans.png"1.4(!21.4.338B0���ڴ��l	Ken Scansen"https://kencomics.com
�

Kewn Scans*eu.kanade.tachiyomi.extension.en.kewnscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kewnscans-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kewnscans.png"1.4(21.4.218B1��Ѻ��ˋ'
Kewn Scansen"https://kewnscans.org
�
Kill Six Billion Demons5eu.kanade.tachiyomi.extension.en.killsixbilliondemons�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.killsixbilliondemons-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.killsixbilliondemons.png"1.4(21.4.68BF՛ݱ����LKillSixBillionDemonsen" https://killsixbilliondemons.com
�
	KingComiX*eu.kanade.tachiyomi.extension.en.kingcomix�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kingcomix-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingcomix.png"1.4(21.4.18B0������Ơ|	KingComiXen"https://kingcomix.com
�
King of Shojo,eu.kanade.tachiyomi.extension.en.kingofshojo�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kingofshojo-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingofshojo.png"1.4( 21.4.328B6��������King of Shojoen"https://kingofshojo.com
�
Kissmanga.in,eu.kanade.tachiyomi.extension.en.kissmangain�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kissmangain-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kissmangain.png"1.4(721.4.558B2��ꠁ�ژ+Kissmanga.inen"https://kissmanga.in
�
K Manga'eu.kanade.tachiyomi.extension.en.kmanga�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kmanga-v1.4.5.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kmanga.png"1.4(21.4.58B4������ԁqK Mangaen"https://kmanga.kodansha.com
�
Kodansha)eu.kanade.tachiyomi.extension.en.kodansha�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kodansha-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kodansha.png"1.4(21.4.18B-������˝Kodanshaen"https://kodansha.us
�
KSGroupScans-eu.kanade.tachiyomi.extension.en.ksgroupscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ksgroupscans-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ksgroupscans.png"1.4(321.4.518B6��̮���;KSGroupScansen"https://ksgroupscans.com
�
Kun Manga Online/eu.kanade.tachiyomi.extension.en.kunmangaonline�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kunmangaonline-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kunmangaonline.png"1.4(421.4.528B=������nKun Manga Onlineen"https://www.kunmanga.online
�
	KuraManga*eu.kanade.tachiyomi.extension.en.kuramanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kuramanga-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kuramanga.png"1.4(21.4.28B0��������b	KuraMangaen"https://kuramanga.com
�
Lagoon Scans,eu.kanade.tachiyomi.extension.en.lagoonscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lagoonscans-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lagoonscans.png"1.4( 21.4.328B5��к�ڤ�mLagoon Scansen"https://lagoonscans.com
�
Leslie&Victims.eu.kanade.tachiyomi.extension.en.leslievictims�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.leslievictims-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.leslievictims.png"1.4(21.4.18B@������̅Leslie&Victimsen" https://leslie-victims.pages.dev
�
LHTranslation.eu.kanade.tachiyomi.extension.en.lhtranslation�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lhtranslation-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lhtranslation.png"1.4(421.4.528B8�楕��ɔzLHTranslationen"https://lhtranslation.net
�
	LikeManga*eu.kanade.tachiyomi.extension.en.likemanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.likemanga-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemanga.png"1.4(21.4.88B0��ݪ����V	LikeMangaen"https://likemanga.ink
�
MangaYY,eu.kanade.tachiyomi.extension.en.likemangain�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.likemangain-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemangain.png"1.4(421.4.528B,���䇞��MangaYYen"https://mangayy.org
�

Lily Manga*eu.kanade.tachiyomi.extension.en.lilymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lilymanga-v1.4.58.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lilymanga.png"1.4(:21.4.588B1��灾��>
Lily Mangaen"https://lilymanga.net
�
	LinkManga*eu.kanade.tachiyomi.extension.en.linkmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.linkmanga-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.linkmanga.png"1.4(321.4.518B0��������w	LinkMangaen"https://linkmanga.com
�
Loading Artist.eu.kanade.tachiyomi.extension.en.loadingartist�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.loadingartist-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.loadingartist.png"1.4(21.4.38B9������Loading Artisten"https://loadingartist.com
�
	Lua Scans)eu.kanade.tachiyomi.extension.en.luascans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.luascans-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luascans.png"1.4(321.4.518B/��������	Lua Scansen"https://luacomic.org
�
Luminare Translations5eu.kanade.tachiyomi.extension.en.luminaretranslations�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.luminaretranslations-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luminaretranslations.png"1.4(21.4.38BG��������Luminare Translationsen" https://luminaretranslations.com
�

Luna Toons*eu.kanade.tachiyomi.extension.en.lunatoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lunatoons-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lunatoons.png"1.4(21.4.208B1��쇨��
Luna Toonsen"https://lunatoons.org
�
LustToon)eu.kanade.tachiyomi.extension.en.lusttoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lusttoon-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lusttoon.png"1.4(21.4.18B-�������KLustToonen"https://lustoon.com
�
	MadaraDex*eu.kanade.tachiyomi.extension.en.madaradex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madaradex-v1.4.54.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madaradex.png"1.4(621.4.548B0ǐ������	MadaraDexen"https://madaradex.org
�
Madara Scans,eu.kanade.tachiyomi.extension.en.madarascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madarascans-v1.4.34.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madarascans.png"1.4("21.4.348B5������Ϡ}Madara Scansen"https://madarascans.com
�
Madokami)eu.kanade.tachiyomi.extension.en.madokami�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madokami-v1.4.14.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madokami.png"1.4(21.4.148B3Ѷ�Ӗ���eMadokamien"https://manga.madokami.al
�
Magus Manga+eu.kanade.tachiyomi.extension.en.magusmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.magusmanga-v1.4.69.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.magusmanga.png"1.4(E21.4.698B2��������Magus Mangaen"https://magustoon.org
�
Mahouirexnohentaikarte7eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mahouirexnohentaikarte-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte.png"1.4(321.4.518BJ�ͬ�����Mahouirexnohentaikarteen""https://mahouirexnohentaikarte.com
�
Manga18.Club,eu.kanade.tachiyomi.extension.en.manga18club�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18club-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18club.png"1.4(21.4.38B2ḉ�����/Manga18.Cluben"https://manga18.club
�
Manga18Free,eu.kanade.tachiyomi.extension.en.manga18free�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18free-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18free.png"1.4(421.4.528B4��������=Manga18Freeen"https://manga18free.com
�
	Manga18fx*eu.kanade.tachiyomi.extension.en.manga18fx�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18fx-v1.4.56.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18fx.png"1.4(821.4.568B0������+	Manga18fxen"https://manga18fx.com
�
	Manga 18x)eu.kanade.tachiyomi.extension.en.manga18x�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18x-v1.4.52.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18x.png"1.4(421.4.528B/���ە��^	Manga 18xen"https://manga18x.net
�
Mangabat)eu.kanade.tachiyomi.extension.en.mangabat�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabat-v1.4.20.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabat.png"1.4(21.4.208B3ڲ򭄪��:Mangabaten"https://www.mangabats.com
�
	Manga-Bay)eu.kanade.tachiyomi.extension.en.mangabay�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabay-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabay.png"1.4(21.4.18B5þ���ឹ 	Manga-Bayen"https://read.manga-bay.org
�

MangaBlaze+eu.kanade.tachiyomi.extension.en.mangablaze�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangablaze-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangablaze.png"1.4(421.4.528B2��悙³�U
MangaBlazeen"https://mangablaze.com
�
	MangaBolt*eu.kanade.tachiyomi.extension.en.mangabolt�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabolt-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabolt.png"1.4(21.4.18B0��堂��	MangaBolten"https://mangabolt.com
�
MangaBTT)eu.kanade.tachiyomi.extension.en.mangabtt�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabtt-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabtt.png"1.4(21.4.58B.���ޚ���lMangaBTTen"https://manhwabtt.cc
�
MangaK+eu.kanade.tachiyomi.extension.en.mangabuddy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabuddy-v1.4.30.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabuddy.png"1.4(21.4.308B)�����ց�EMangaKen"https://mangak.io
�
Mangack(eu.kanade.tachiyomi.extension.en.mangack�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangack-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangack.png"1.4(21.4.28B,��č����dMangacken"https://mangack.com
�

MangaCloud+eu.kanade.tachiyomi.extension.en.mangacloud�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangacloud-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangacloud.png"1.4(21.4.78B2�������y
MangaClouden"https://mangacloud.org
�

Manga Dass*eu.kanade.tachiyomi.extension.en.mangadass�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadass-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadass.png"1.4(421.4.528B1���ϕ��M
Manga Dassen"https://mangadass.com
�
MangaDE(eu.kanade.tachiyomi.extension.en.mangade�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangade-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangade.png"1.4(21.4.18B+����ƞ��/MangaDEen"https://mangade.io
�
Manga Demon+eu.kanade.tachiyomi.extension.en.mangademon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangademon-v1.4.19.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangademon.png"1.4(21.4.198B5ڹ�ܒ���(Manga Demonen"https://demonicscans.org
�
MangaDia)eu.kanade.tachiyomi.extension.en.mangadia�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadia-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadia.png"1.4(321.4.518B.�ҥă��MangaDiaen"https://mangadia.com
�
Manga District.eu.kanade.tachiyomi.extension.en.mangadistrict�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadistrict-v1.4.67.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadistrict.png"1.4(C21.4.678B9��������)Manga Districten"https://mangadistrict.com
�
Mangadotnet,eu.kanade.tachiyomi.extension.en.mangadotnet�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadotnet-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadotnet.png"1.4(21.4.128B1��ٙ�ɕ�QMangadotneten"https://mangadot.net
�
Manga Drama+eu.kanade.tachiyomi.extension.en.mangadrama�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadrama-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadrama.png"1.4(321.4.518B3�������,Manga Dramaen"https://mangadrama.com
�
Mangaforfree.com0eu.kanade.tachiyomi.extension.en.mangaforfreecom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaforfreecom-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaforfreecom.png"1.4(521.4.538B:����ԗΠMangaforfree.comen"https://mangaforfree.com
�
MangaFox)eu.kanade.tachiyomi.extension.en.mangafox�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafox-v1.4.9.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafox.png"1.4(	21.4.98B,Ц������YMangaFoxen"https://fanfox.net
�
MangaFox.fun,eu.kanade.tachiyomi.extension.en.mangafoxfun�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafoxfun-v1.4.35.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafoxfun.png"1.4(#21.4.358B2������߂qMangaFox.funen"https://mangafox.fun
�

Mangafreak+eu.kanade.tachiyomi.extension.en.mangafreak�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafreak-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafreak.png"1.4(21.4.138B5�֬����
Mangafreaken"https://ww2.mangafreak.me
�
	Mangafree*eu.kanade.tachiyomi.extension.en.mangafree�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafree-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafree.png"1.4(321.4.518B1��Ԫۧ��.	Mangafreeen"https://mangafree.info
�
MangaGG(eu.kanade.tachiyomi.extension.en.mangagg�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangagg-v1.4.54.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagg.png"1.4(621.4.548B,Ά���նqMangaGGen"https://mangagg.com
�
Mangago(eu.kanade.tachiyomi.extension.en.mangago�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangago-v1.4.34.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangago.png"1.4("21.4.348B/ژ����ڣ"Mangagoen"https://www.mangago.me
�
MangaGo.fun+eu.kanade.tachiyomi.extension.en.mangagofun�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangagofun-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagofun.png"1.4(321.4.518B4��ڑо��XMangaGo.funen"https://www.mangago.fun
�
MangaHe(eu.kanade.tachiyomi.extension.en.mangahe�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahe-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahe.png"1.4(321.4.518B,��������MangaHeen"https://mangahe.com
�
Gensura)eu.kanade.tachiyomi.extension.en.mangahen�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahen-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahen.png"1.4(21.4.38B,��﫱��[Gensuraen"https://gensura.net
�
Manga Hentai,eu.kanade.tachiyomi.extension.en.mangahentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahentai-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahentai.png"1.4(721.4.558B4���嘑yManga Hentaien"https://mangahentai.me
�
	Mangahere*eu.kanade.tachiyomi.extension.en.mangahere�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahere-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahere.png"1.4(21.4.238B+	Mangahereen"https://www.mangahere.cc
�
MangaHere.onl-eu.kanade.tachiyomi.extension.en.mangahereonl�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahereonl-v1.4.35.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahereonl.png"1.4(#21.4.358B4��������6MangaHere.onlen"https://mangahere.onl
�
MangaHub+eu.kanade.tachiyomi.extension.en.mangahubio�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahubio-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahubio.png"1.4(-21.4.458B-�ۢ�����BMangaHuben"https://mangahub.io
�
MangaKa(eu.kanade.tachiyomi.extension.en.mangaka�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaka-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaka.png"1.4(321.4.518B+��Ɔ����-MangaKaen"https://mangaka.cc
�
Mangakakalot-eu.kanade.tachiyomi.extension.en.mangakakalot�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakakalot-v1.4.21.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalot.png"1.4(21.4.218B9�闥����#Mangakakaloten"https://www.mangakakalot.gg
�
Mangakakalot.fun0eu.kanade.tachiyomi.extension.en.mangakakalotfun�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakakalotfun-v1.4.35.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalotfun.png"1.4(#21.4.358B:������ŊZMangakakalot.funen"https://mangakakalot.fun
�
MangaKatana,eu.kanade.tachiyomi.extension.en.mangakatana�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakatana-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakatana.png"1.4(21.4.128B4��������,MangaKatanaen"https://mangakatana.com
�

Manga Kiss*eu.kanade.tachiyomi.extension.en.mangakiss�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakiss-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakiss.png"1.4(421.4.528B1�����І�!
Manga Kissen"https://mangakiss.org
�
MangaManiacs-eu.kanade.tachiyomi.extension.en.mangamaniacs�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamaniacs-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamaniacs.png"1.4(321.4.518B6������׮LMangaManiacsen"https://mangamaniacs.org
�
Manga Mirai+eu.kanade.tachiyomi.extension.en.mangamirai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamirai-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamirai.png"1.4(21.4.18B3��䳁���/Manga Miraien"https://mangamirai.com
�
Mangamo(eu.kanade.tachiyomi.extension.en.mangamo�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamo-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamo.png"1.4(21.4.78B0���ğ��YMangamoen"https://www.mangamo.com
�
Comivex)eu.kanade.tachiyomi.extension.en.mangamob�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamob-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamob.png"1.4(21.4.38B,��������Comivexen"https://comivex.com
�
MangaNel)eu.kanade.tachiyomi.extension.en.manganel�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganel-v1.4.35.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganel.png"1.4(#21.4.358B-�㽢����	MangaNelen"https://manganel.me
�
	Manganato*eu.kanade.tachiyomi.extension.en.manganelo�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganelo-v1.4.18.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganelo.png"1.4(21.4.188B4��������	Manganatoen"https://www.natomanga.com
�
MangaNow)eu.kanade.tachiyomi.extension.en.manganow�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganow-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganow.png"1.4(21.4.48B-��������MangaNowen"https://manganow.to
�
MangaOnline.fun/eu.kanade.tachiyomi.extension.en.mangaonlinefun�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaonlinefun-v1.4.35.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaonlinefun.png"1.4(#21.4.358B8�������IMangaOnline.funen"https://mangaonline.fun
�
MangaOwl.io (unoriginal)+eu.kanade.tachiyomi.extension.en.mangaowlio�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaowlio-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaowlio.png"1.4(421.4.528B=�ʅ�՘MangaOwl.io (unoriginal)en"https://mangaowl.io
�
MangaPanda.onl.eu.kanade.tachiyomi.extension.en.mangapandaonl�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangapandaonl-v1.4.35.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapandaonl.png"1.4(#21.4.358B6����ڴ�jMangaPanda.onlen"https://mangapanda.onl
�
	MangaPill*eu.kanade.tachiyomi.extension.en.mangapill�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangapill-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapill.png"1.4(	21.4.98B0��ҧҩ��u	MangaPillen"https://mangapill.com
�
	MangaGeko-eu.kanade.tachiyomi.extension.en.mangarawclub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangarawclub-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangarawclub.png"1.4( 21.4.328B/���ۊ���
	MangaGekoen"https://www.mgeko.cc
�

Manga Read*eu.kanade.tachiyomi.extension.en.mangaread�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaread-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaread.png"1.4(421.4.528B0����֘��z
Manga Readen"https://mangaread.co
�
MangaReader.in.eu.kanade.tachiyomi.extension.en.mangareadercc�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadercc-v1.4.6.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadercc.png"1.4(21.4.68B6ٺ������fMangaReader.inen"https://mangareader.in
�
MangaReader.site0eu.kanade.tachiyomi.extension.en.mangareadersite�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadersite-v1.4.35.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadersite.png"1.4(#21.4.358B:���ԘŚ�#MangaReader.siteen"https://mangareader.site
�
MangaRead.org-eu.kanade.tachiyomi.extension.en.mangareadorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadorg-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadorg.png"1.4(521.4.538B8�۷���ț%MangaRead.orgen"https://www.mangaread.org
�

Mangasushi+eu.kanade.tachiyomi.extension.en.mangasushi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangasushi-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasushi.png"1.4(621.4.548B2�۸����2
Mangasushien"https://mangasushi.org
�
Mangatellers-eu.kanade.tachiyomi.extension.en.mangatellers�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatellers-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatellers.png"1.4(21.4.58B<��Ϻ��ӣ0Mangatellersen"https://reader.mangatellers.gr
�

MangaToday+eu.kanade.tachiyomi.extension.en.mangatoday�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatoday-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatoday.png"1.4(#21.4.358B2�������
MangaTodayen"https://mangatoday.fun
�
	Mangatown*eu.kanade.tachiyomi.extension.en.mangatown�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatown-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatown.png"1.4(
21.4.108B4���Ԩ���%	Mangatownen"https://www.mangatown.com
�
Manga Trend+eu.kanade.tachiyomi.extension.en.mangatrend�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatrend-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatrend.png"1.4( 21.4.328B3�������Manga Trenden"https://mangatrend.org
�
MangaTX(eu.kanade.tachiyomi.extension.en.mangatx�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatx-v1.4.33.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatx.png"1.4(!21.4.338B+������-MangaTXen"https://mangatx.cc
�

ManhuaFast+eu.kanade.tachiyomi.extension.en.manhuafast�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuafast-v1.4.55.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafast.png"1.4(721.4.558B2̗�Ӓ��K
ManhuaFasten"https://manhuafast.com
�
ManhuaFast.net (unoriginal).eu.kanade.tachiyomi.extension.en.manhuafastnet�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuafastnet-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafastnet.png"1.4(321.4.518BC٘�����6ManhuaFast.net (unoriginal)en"https://manhuafast.net
�
	ManhuaHot*eu.kanade.tachiyomi.extension.en.manhuahot�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuahot-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuahot.png"1.4(321.4.518B0�����Հj	ManhuaHoten"https://manhuahot.com
�

Manhuanext+eu.kanade.tachiyomi.extension.en.manhuanext�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuanext-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuanext.png"1.4(421.4.528B2��ʂ΄��1
Manhuanexten"https://manhuanext.com
�
Manhua Plus+eu.kanade.tachiyomi.extension.en.manhuaplus�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaplus-v1.4.58.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplus.png"1.4(:21.4.588B3�������}Manhua Plusen"https://manhuaplus.com
�
ManhuaPlus (unoriginal).eu.kanade.tachiyomi.extension.en.manhuaplusorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaplusorg-v1.4.6.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplusorg.png"1.4(21.4.68B?�����ޕ�FManhuaPlus (Unoriginal)en"https://manhuaplus.org
�
Manhua Rush+eu.kanade.tachiyomi.extension.en.manhuarush�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuarush-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuarush.png"1.4(21.4.28B:ҟƔ����NManhua Rushen"https://manhuarush.vercel.app
�
Manhuascan.us-eu.kanade.tachiyomi.extension.en.manhuascanus�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuascanus-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuascanus.png"1.4( 21.4.328B4��������ZManhuascan.usen"https://manhuascan.us
�
	ManhuaTop*eu.kanade.tachiyomi.extension.en.manhuatop�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuatop-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuatop.png"1.4(421.4.528B0ܪ�聾�	ManhuaTopen"https://manhuatop.org
�
ManhuaUS)eu.kanade.tachiyomi.extension.en.manhuaus�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaus-v1.4.56.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaus.png"1.4(821.4.568B.��֞��7ManhuaUSen"https://manhuaus.com
�
Manhua Zonghe-eu.kanade.tachiyomi.extension.en.manhuazonghe�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuazonghe-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuazonghe.png"1.4(421.4.528B;�����TManhua Zongheen"https://www.manhuazonghe.com
�
Manhwa18)eu.kanade.tachiyomi.extension.en.manhwa18�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa18-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18.png"1.4(21.4.138B-�ڐ��̋2Manhwa18en"https://manhwa18.com
�
Manhwa18.org,eu.kanade.tachiyomi.extension.en.manhwa18org�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa18org-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18org.png"1.4(521.4.538B2��橽��|Manhwa18.orgen"https://manhwa18.org
�
Manhwa68)eu.kanade.tachiyomi.extension.en.manhwa68�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa68-v1.4.54.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa68.png"1.4(621.4.548B.��߇܋�%Manhwa68en"https://manhwa68.com
�
ManhwaBuddy,eu.kanade.tachiyomi.extension.en.manhwabuddy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwabuddy-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwabuddy.png"1.4(21.4.38B4������ManhwaBuddyen"https://manhwabuddy.com
�
Manhwa Comics-eu.kanade.tachiyomi.extension.en.manhwacomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwacomics-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwacomics.png"1.4(321.4.518B7爵֢���.Manhwa Comicsen"https://manhwacomics.com
�
	ManhwaDen*eu.kanade.tachiyomi.extension.en.manhwaden�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaden-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaden.png"1.4(321.4.518B4�̤�����j	ManhwaDenen"https://www.manhwaden.com
�
	ManhwaGet*eu.kanade.tachiyomi.extension.en.manhwaget�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaget-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaget.png"1.4(321.4.518B0ͨ��ʾ�)	ManhwaGeten"https://manhwaget.com
�
	ManhwaHub*eu.kanade.tachiyomi.extension.en.manhwahub�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwahub-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwahub.png"1.4(21.4.58B0ن�ڕ���	ManhwaHuben"https://manhwahub.net
�
	Manhwajoy*eu.kanade.tachiyomi.extension.en.manhwajoy�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwajoy-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwajoy.png"1.4(321.4.518B0��������	Manhwajoyen"https://manhwajoy.com
�

Manhwalike+eu.kanade.tachiyomi.extension.en.manhwalike�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwalike-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalike.png"1.4(21.4.38B2��������0
Manhwalikeen"https://manhwalike.com
�
Manhwalover,eu.kanade.tachiyomi.extension.en.manhwalover�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwalover-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalover.png"1.4( 21.4.328B8�ڮ٦đ�QManhwaloveren"https://www.manhwalover.org
�
ManhwaManhua-eu.kanade.tachiyomi.extension.en.manhwamanhua�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwamanhua-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwamanhua.png"1.4(321.4.518B6Բ�����|ManhwaManhuaen"https://manhwamanhua.com
�
	ManhwaNex*eu.kanade.tachiyomi.extension.en.manhwanex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwanex-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwanex.png"1.4(321.4.518B0�ۆ����2	ManhwaNexen"https://manhwanex.com
�

ManhwaRead+eu.kanade.tachiyomi.extension.en.manhwaread�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaread-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaread.png"1.4(21.4.18BKӋ��Ƀ�
ManhwaReaden"/https://manhwaread.com#, https://manhwaread.org
�
Manhwa Reads,eu.kanade.tachiyomi.extension.en.manhwareads�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwareads-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwareads.png"1.4(321.4.518B5��������.Manhwa Readsen"https://manhwareads.com
�
Manhwa Toon+eu.kanade.tachiyomi.extension.en.manhwatoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwatoon-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatoon.png"1.4(421.4.528B6���춂��1Manhwa Toonen"https://www.manhwatoon.me
�
	Manhwatop*eu.kanade.tachiyomi.extension.en.manhwatop�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwatop-v1.4.53.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatop.png"1.4(521.4.538B0�������G	Manhwatopen"https://manhwatop.com
�
Manhwax(eu.kanade.tachiyomi.extension.en.manhwax�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwax-v1.4.32.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwax.png"1.4( 21.4.328B,�����Ԫ�eManhwaxen"https://manhwax.top
�

Manhwa XXL*eu.kanade.tachiyomi.extension.en.manhwaxxl�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaxxl-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaxxl.png"1.4(21.4.68B1��ӯ����
Manhwa XXLen"https://hentaitnt.net
�
ManhwaZ(eu.kanade.tachiyomi.extension.en.manhwaz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaz-v1.4.42.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaz.png"1.4(*21.4.428B,ْ���	ManhwaZen"https://manhwaz.com
�

ManhwaZone+eu.kanade.tachiyomi.extension.en.manhwazone�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwazone-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwazone.png"1.4(21.4.18B2�Ύ��֡�
ManhwaZoneen"https://manhwazone.com
�
	Megatokyo*eu.kanade.tachiyomi.extension.en.megatokyo�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.megatokyo-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.megatokyo.png"1.4(21.4.48B0��������$	Megatokyoen"https://megatokyo.com
�
	Mehgazone*eu.kanade.tachiyomi.extension.en.mehgazone�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mehgazone-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mehgazone.png"1.4(21.4.28B0�뎄뻊�%	Mehgazoneen"https://mehgazone.com
�
MeiToon(eu.kanade.tachiyomi.extension.en.meitoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.meitoon-v1.4.20.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.meitoon.png"1.4(21.4.208B,�ʅ����-MeiToonen"https://meitoon.org
�
	Mgread.io)eu.kanade.tachiyomi.extension.en.mgreadio�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mgreadio-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mgreadio.png"1.4(21.4.18B+������	Mgread.ioen"https://mgread.io
�
Milftoon)eu.kanade.tachiyomi.extension.en.milftoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.milftoon-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.milftoon.png"1.4(521.4.538B.��ϜȖ��7Milftoonen"https://milftoon.xxx
�

Mist Scans*eu.kanade.tachiyomi.extension.en.mistscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mistscans-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mistscans.png"1.4(21.4.218B1ݤ쓯˞�
Mist Scansen"https://mistscans.com
�
	MLBB Lore)eu.kanade.tachiyomi.extension.en.mlbblore�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mlbblore-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mlbblore.png"1.4(21.4.18B@�����MLBB Lore Comicsen"https://play.mobilelegends.com
�
Monochrome Custom1eu.kanade.tachiyomi.extension.en.monochromecustom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.monochromecustom-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromecustom.png"1.4(21.4.68BD�������Monochrome Customen"!https://monochromecms.netlify.app
�
Monochrome Scans0eu.kanade.tachiyomi.extension.en.monochromescans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.monochromescans-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromescans.png"1.4(21.4.58B8�Ǟ�Ɣ��^Monochrome Scansen"https://manga.d34d.one
�
Multporn)eu.kanade.tachiyomi.extension.en.multporn�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.multporn-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.multporn.png"1.4(21.4.68B.�����Multpornen"https://multporn.net
�
	MurimScan*eu.kanade.tachiyomi.extension.en.murimscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.murimscan-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.murimscan.png"1.4(121.4.498B6�������L	MurimScanen"https://www.murimscans.site
�
MyAdultComics.eu.kanade.tachiyomi.extension.en.myadultcomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myadultcomics-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myadultcomics.png"1.4(21.4.18B8������9MyAdultComicsen"https://myadultcomics.com
�
MyHentaiComics/eu.kanade.tachiyomi.extension.en.myhentaicomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myhentaicomics-v1.4.4.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaicomics.png"1.4(21.4.48B:�����ǌ�DMyHentaiComicsen"https://myhentaicomics.com
�
MyHentaiGallery0eu.kanade.tachiyomi.extension.en.myhentaigallery�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myhentaigallery-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaigallery.png"1.4(	21.4.98B<���ر��eMyHentaiGalleryen"https://myhentaigallery.com
�
Necro Scans+eu.kanade.tachiyomi.extension.en.necroscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.necroscans-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.necroscans.png"1.4(21.4.208B3�����BNecro Scansen"https://necroscans.com
�

New Manhwa*eu.kanade.tachiyomi.extension.en.newmanhwa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.newmanhwa-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.newmanhwa.png"1.4("21.4.348B1�ϣԀ��2
New Manhwaen"https://newmanhwa.com
�
NexComic)eu.kanade.tachiyomi.extension.en.nexcomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nexcomic-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nexcomic.png"1.4( 21.4.328B.ε������)NexComicen"https://nexcomic.com
�

Nika Toons*eu.kanade.tachiyomi.extension.en.nikatoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nikatoons-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nikatoons.png"1.4( 21.4.328B1�����̓�
Nika Toonsen"https://nikatoons.com
�
	NineAnime*eu.kanade.tachiyomi.extension.en.nineanime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nineanime-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nineanime.png"1.4(21.4.68B4����ԯ*	NineAnimeen"https://www.nineanime.com
�

NineHentai+eu.kanade.tachiyomi.extension.en.ninehentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ninehentai-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninehentai.png"1.4(21.4.68B.�Ҙ��ݣ�j
NineHentaien"https://9hentai.so
�
Ninekon(eu.kanade.tachiyomi.extension.en.ninekon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ninekon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninekon.png"1.4(21.4.18B0�ء�٬��=Ninekonen"https://app.ninekon.com
�
NixManga)eu.kanade.tachiyomi.extension.en.nixmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nixmanga-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nixmanga.png"1.4(21.4.28B.�������0NixMangaen"https://nixmanga.com
�
24HNovel)eu.kanade.tachiyomi.extension.en.novel24h�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.novel24h-v1.4.52.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novel24h.png"1.4(421.4.528B.��������t24HNovelen"https://24hnovel.com
�
	NovelCrow*eu.kanade.tachiyomi.extension.en.novelcrow�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.novelcrow-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novelcrow.png"1.4(421.4.528B0ڭ����<	NovelCrowen"https://novelcrow.com
�
Noxen Scans+eu.kanade.tachiyomi.extension.en.noxenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.noxenscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.noxenscans.png"1.4( 21.4.328B2Ζ�˙���+Noxen Scansen"https://noxenscan.com
�
	Nux Scans)eu.kanade.tachiyomi.extension.en.nuxscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nuxscans-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nuxscans.png"1.4(21.4.28B?�輊��ŠQ	Nux Scansen"$https://nuxscans-comics.blogspot.com
�

Nyanu Kafe*eu.kanade.tachiyomi.extension.en.nyanukafe�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyanukafe-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyanukafe.png"1.4(21.4.218B1������)
Nyanu Kafeen"https://nyanukafe.com
�

Nyra Scans*eu.kanade.tachiyomi.extension.en.nyrascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyrascans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyrascans.png"1.4(21.4.208B1�צ����
Nyra Scansen"https://nyrascans.com
�
	Nyx Scans)eu.kanade.tachiyomi.extension.en.nyxscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyxscans-v1.4.26.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyxscans.png"1.4(21.4.268B/�������	Nyx Scansen"https://nyxscans.com
�
OctopusManga-eu.kanade.tachiyomi.extension.en.octopusmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.octopusmanga-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.octopusmanga.png"1.4(321.4.518B6��������#OctopusMangaen"https://octopusmanga.com
�
Oglaf&eu.kanade.tachiyomi.extension.en.oglaf�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oglaf-v1.4.4.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oglaf.png"1.4(21.4.48B,������Oglafen"https://www.oglaf.com
�
Oh Joy Sex Toy,eu.kanade.tachiyomi.extension.en.ohjoysextoy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ohjoysextoy-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ohjoysextoy.png"1.4(21.4.38B;��蟈�>Oh Joy Sex Toyen"https://www.ohjoysextoy.com
�
Omega Scans+eu.kanade.tachiyomi.extension.en.omegascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.omegascans-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.omegascans.png"1.4(221.4.508B3�֢���ݥOmega Scansen"https://omegascans.org
�
	1Manga.co+eu.kanade.tachiyomi.extension.en.onemangaco�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onemangaco-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangaco.png"1.4(#21.4.358B,�陾���W	1Manga.coen"https://1manga.co
�
OneManga.info-eu.kanade.tachiyomi.extension.en.onemangainfo�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onemangainfo-v1.4.35.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangainfo.png"1.4(#21.4.358B4���η�OneManga.infoen"https://onemanga.info
�
One Punch Man Online2eu.kanade.tachiyomi.extension.en.onepunchmanonline�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onepunchmanonline-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onepunchmanonline.png"1.4(21.4.28B?�΂�ݨȹOne Punch Man Onlineen"https://w11.1punchman.com
�
Only The Best Hentai2eu.kanade.tachiyomi.extension.en.onlythebesthentai�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onlythebesthentai-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onlythebesthentai.png"1.4(21.4.18BC�����Ҵ�QOnly The Best Hentaien"https://onlythebesthentai.com
�
oots%eu.kanade.tachiyomi.extension.en.oots�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oots-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oots.png"1.4(21.4.38BG����酗�`The Order Of The Stick (OOTS)en"https://www.giantitp.com
�
Oppai Stream,eu.kanade.tachiyomi.extension.en.oppaistream�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oppaistream-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oppaistream.png"1.4(21.4.58B7��������Oppai Streamen"https://read.oppai.stream
�

Orchisasia+eu.kanade.tachiyomi.extension.en.orchisasia�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.orchisasia-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orchisasia.png"1.4(321.4.518B6�����=
Orchisasiaen"https://www.orchisasia.org
�
Orion Scans+eu.kanade.tachiyomi.extension.en.orionscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.orionscans-v1.4.23.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orionscans.png"1.4(21.4.238B4���๟��kOrion Scansen"https://orion-scans.com
�
Paradise Scans.eu.kanade.tachiyomi.extension.en.paradisescans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.paradisescans-v1.4.20.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paradisescans.png"1.4(21.4.208B8�������RParadiseScansen"https://paradisescans.com
�
Paritehaber,eu.kanade.tachiyomi.extension.en.paritehaber�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.paritehaber-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paritehaber.png"1.4(421.4.528B8���¢��3Paritehaberen"https://www.paritehaber.com
�
Patch Friday,eu.kanade.tachiyomi.extension.en.patchfriday�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.patchfriday-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.patchfriday.png"1.4(21.4.28B5��׏�Ɖ�PPatch Fridayen"https://patchfriday.com
�
	Paw Manga)eu.kanade.tachiyomi.extension.en.pawmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.pawmanga-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pawmanga.png"1.4(321.4.518B/ѿ�ߧ���>	Paw Mangaen"https://pawmanga.com
�
Petrotechsociety1eu.kanade.tachiyomi.extension.en.petrotechsociety�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.petrotechsociety-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.petrotechsociety.png"1.4(321.4.518BA�񄂆��#Petrotechsocietyen" https://www.petrotechsociety.org
�
Philia Scans,eu.kanade.tachiyomi.extension.en.philiascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.philiascans-v1.4.58.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.philiascans.png"1.4(:21.4.588B5�������KPhilia Scansen"https://philiascans.org
�
FlameScans.lol+eu.kanade.tachiyomi.extension.en.plutoscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.plutoscans-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.plutoscans.png"1.4(421.4.528B6�������FlameScans.lolen"https://flamescans.lol
�
Rackus(eu.kanade.tachiyomi.extension.en.pmscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.pmscans-v1.4.39.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pmscans.png"1.4('21.4.398B/����л��Rackusen"https://rackusreads.com
�
	PornComix*eu.kanade.tachiyomi.extension.en.porncomix�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.porncomix-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.porncomix.png"1.4(121.4.498B4����ؙ��[	PornComixen"https://bestporncomix.com
�
Qi Scans(eu.kanade.tachiyomi.extension.en.qiscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.qiscans-v1.4.26.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.qiscans.png"1.4(21.4.268B,��Җ���PQiScansen"https://qimanga.com
�
Questionable Content4eu.kanade.tachiyomi.extension.en.questionablecontent�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.questionablecontent-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.questionablecontent.png"1.4(
21.4.108BI�ۈ�����MQuestionable Contenten"#https://www.questionablecontent.net
�

Rage Scans*eu.kanade.tachiyomi.extension.en.ragescans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ragescans-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ragescans.png"1.4(!21.4.338B1��������x
Rage Scansen"https://ragescans.com
�
Randowiz)eu.kanade.tachiyomi.extension.en.randowiz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.randowiz-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.randowiz.png"1.4(21.4.28B.݇�ײ���Randowizen"https://randowis.com
�
Raven Scans+eu.kanade.tachiyomi.extension.en.ravenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ravenscans-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ravenscans.png"1.4("21.4.348B3�����ˀ�GRaven Scansen"https://ravenscans.org
�
Razure'eu.kanade.tachiyomi.extension.en.razure�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.razure-v1.4.32.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.razure.png"1.4( 21.4.328B*׌������)Razureen"https://razure.org
�
RD Scans(eu.kanade.tachiyomi.extension.en.rdscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rdscans-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rdscans.png"1.4(321.4.518B-��������"RD Scansen"https://rdscans.com
�
ReadAllComics1eu.kanade.tachiyomi.extension.en.readallcomicscom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readallcomicscom-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readallcomicscom.png"1.4(21.4.88B7�݊ʨ�gReadAllComicsen"https://readallcomics.com
�
-Read Attack on Titan Shingeki no Kyojin MangaGeu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readattackontitanshingekinokyojinmanga-v1.4.13.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga.png"1.4(21.4.138BW촀�ꏥ�{-Read Attack on Titan Shingeki no Kyojin Mangaen"https://ww11.readsnk.com
�
Read Berserk Manga1eu.kanade.tachiyomi.extension.en.readberserkmanga�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readberserkmanga-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readberserkmanga.png"1.4(21.4.88B;�����ۯ�DRead Berserk Mangaen"https://readberserk.com
�
Read Black Clover Manga Online;eu.kanade.tachiyomi.extension.en.readblackclovermangaonline�
}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readblackclovermangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readblackclovermangaonline.png"1.4(21.4.88BP��ף�̫�ZRead Black Clover Manga Onlineen" https://ww10.readblackclover.com
�
1Read Boku no Hero Academia My Hero Academia MangaJeu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readbokunoheroacademiamyheroacademiamanga-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga.png"1.4(
21.4.108B[��ܢ���D1Read Boku no Hero Academia My Hero Academia Mangaen"https://ww10.readmha.com
�
Read Chainsaw Man Manga Online;eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline�
}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readchainsawmanmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline.png"1.4(	21.4.98BO�ӆ��ʢ�VRead Chainsaw Man Manga Onlineen"https://ww5.readchainsawman.com
�
ReadComicOnline0eu.kanade.tachiyomi.extension.en.readcomiconline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readcomiconline-v1.4.43.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomiconline.png"1.4(+21.4.438B7��������oReadComicOnlineen"https://rcostation.xyz
�
Read Comics Online1eu.kanade.tachiyomi.extension.en.readcomicsonline�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readcomicsonline-v1.4.14.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomicsonline.png"1.4(21.4.148B?�����ɘ�cRead Comics Onlineen"https://readcomicsonline.ru
�
)Read Fairy Tail & Edens Zero Manga OnlineBeu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readfairytailedenszeromangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline.png"1.4(	21.4.98BX������)Read Fairy Tail & Edens Zero Manga Onlineen"https://ww8.readfairytail.com
�
 Read Jujutsu Kaisen Manga Online=eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline�
https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readjujutsukaisenmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline.png"1.4(	21.4.98BS������� Read Jujutsu Kaisen Manga Onlineen"!https://ww5.readjujutsukaisen.com
�
Read Kingdom Manga Online7eu.kanade.tachiyomi.extension.en.readkingdommangaonline�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readkingdommangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readkingdommangaonline.png"1.4(21.4.88BF��������nRead Kingdom Manga Onlineen"https://ww5.readkingdom.com
�
1Read Nanatsu no Taizai 7 Deadly Sins Manga OnlineJeu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readnanatsunotaizai7deadlysinsmangaonline-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline.png"1.4(
21.4.108Bb��������61Read Nanatsu no Taizai 7 Deadly Sins Manga Onlineen"https://ww7.read7deadlysins.com
�
)Read Naruto Boruto Samurai 8 Manga OnlineDeu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readnarutoborutosamurai8mangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline.png"1.4(	21.4.98BVȼ���΅�9)Read Naruto Boruto Samurai 8 Manga Onlineen"https://ww11.readnaruto.com
�
Read One Piece Manga Online8eu.kanade.tachiyomi.extension.en.readonepiecemangaonline�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readonepiecemangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepiecemangaonline.png"1.4(21.4.88BJ�ͅ�Ӫ��Read One Piece Manga Onlineen"https://ww12.readonepiece.com
�
Read One-Punch Man Manga Online>eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readonepunchmanmangaonlinetwo-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo.png"1.4(21.4.88BH��欆��rRead One-Punch Man Manga Onlineen"https://ww6.readopm.com
�
&Read Solo Leveling Manga Manhwa OnlineBeu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readsololevelingmangamanhwaonline-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline.png"1.4(
21.4.108BX�����讉&Read Solo Leveling Manga Manhwa Onlineen" https://ww3.readsololeveling.org
�
.Read Tokyo Ghoul Re & Tokyo Ghoul Manga OnlineFeu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readtokyoghoulretokyoghoulmangaonline-v1.4.11.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline.png"1.4(21.4.118B]˖������Y.Read Tokyo Ghoul Re & Tokyo Ghoul Manga Onlineen"https://ww11.tokyoghoulre.com
�
Read Vagabond Manga2eu.kanade.tachiyomi.extension.en.readvagabondmanga�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readvagabondmanga-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readvagabondmanga.png"1.4(21.4.18B>��������IRead Vagabond Mangaen"https://readbagabondo.com
�
Real Life Comics/eu.kanade.tachiyomi.extension.en.reallifecomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.reallifecomics-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reallifecomics.png"1.4(21.4.38B<�������CReal Life Comicsen"https://reallifecomics.com
�
ReiManga)eu.kanade.tachiyomi.extension.en.reimanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.reimanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reimanga.png"1.4(21.4.18B.��������NReiMangaen"https://reimanga.com
�
	Renascans*eu.kanade.tachiyomi.extension.en.renascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.renascans-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.renascans.png"1.4(21.4.238B0��ۗ����/	Renascansen"https://renascans.net
�

Rest Scans*eu.kanade.tachiyomi.extension.en.restscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.restscans-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.restscans.png"1.4( 21.4.328B1ϑ������7
Rest Scansen"https://restscans.com
�
Revival Scans-eu.kanade.tachiyomi.extension.en.revivalscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.revivalscans-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.revivalscans.png"1.4(21.4.18B;���Ż´_Revival Scansen"https://www.revivalscans.com
�
Rinko Comics,eu.kanade.tachiyomi.extension.en.rinkocomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rinkocomics-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rinkocomics.png"1.4(21.4.28B5���΂��DRinko Comicsen"https://rinkocomics.com
�
RitharScans,eu.kanade.tachiyomi.extension.en.ritharscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ritharscans-v1.4.23.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ritharscans.png"1.4(21.4.238B4�؃�����rRitharScansen"https://ritharscans.com
�

Rizz Comic*eu.kanade.tachiyomi.extension.en.rizzcomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rizzcomic-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomic.png"1.4(-21.4.458B2�����*
Rizz Comicen"https://rizzfables.com
�
Rizz Comic (unoriginal)4eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rizzcomicunoriginal-v1.4.32.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal.png"1.4( 21.4.328B>�㖌߁��|Rizz Comic (unoriginal)en"https://rizzcomic.com
�
RokariComics-eu.kanade.tachiyomi.extension.en.rokaricomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rokaricomics-v1.4.34.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rokaricomics.png"1.4("21.4.348B6䂴��RokariComicsen"https://rokaricomics.com
�

Rolia Scan*eu.kanade.tachiyomi.extension.en.roliascan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.roliascan-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.roliascan.png"1.4(21.4.88B1�����/
Rolia Scanen"https://roliascan.com
�
Rose Squad Scans/eu.kanade.tachiyomi.extension.en.rosesquadscans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rosesquadscans-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rosesquadscans.png"1.4(421.4.528BF�����ޛ�KRose Squad Scansen"$https://rosesquadscans.aishiteru.org
�
Ryumanga)eu.kanade.tachiyomi.extension.en.ryumanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ryumanga-v1.4.20.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ryumanga.png"1.4(21.4.208B.݃�����@Ryumangaen"https://ryumanga.org
�
S2Manga(eu.kanade.tachiyomi.extension.en.s2manga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.s2manga-v1.4.55.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.s2manga.png"1.4(721.4.558B+����ϼ��CS2Mangaen"https://s2read.com
�
Sabrina Online.eu.kanade.tachiyomi.extension.en.sabrinaonline�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sabrinaonline-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sabrinaonline.png"1.4(21.4.18B>��������Sabrina Onlineen"https://www.sabrina-online.com
�

SACACHISPA+eu.kanade.tachiyomi.extension.en.sacachispa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sacachispa-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sacachispa.png"1.4(21.4.18B3�������
SACACHISPAen"https://sacachispa.site
�

Sana Scans*eu.kanade.tachiyomi.extension.en.sanascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sanascans-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sanascans.png"1.4(21.4.238B1����ꔆ�
Sana Scansen"https://sanascans.com
�
!Saturday Morning Breakfast Comics?eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.saturdaymorningbreakfastcomics-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics.png"1.4(21.4.28BJɴ����Ԑ*!Saturday Morning Breakfast Comicsen"https://smbc-comics.com
�
ScansGG(eu.kanade.tachiyomi.extension.en.scansgg�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.scansgg-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.scansgg.png"1.4(21.4.18B)��ҧ���SScansGGen"https://scans.gg
�
Schlock Mercenary1eu.kanade.tachiyomi.extension.en.schlockmercenary�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.schlockmercenary-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.schlockmercenary.png"1.4(21.4.28BC鞙�����ASchlock Mercenaryen" https://www.schlockmercenary.com
�
Setsu Scans+eu.kanade.tachiyomi.extension.en.setsuscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.setsuscans-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.setsuscans.png"1.4(621.4.548B3���ޟ��vSetsu Scansen"https://setsuscans.com
�
Shiba Manga+eu.kanade.tachiyomi.extension.en.shibamanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.shibamanga-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shibamanga.png"1.4(321.4.518B3�����"Shiba Mangaen"https://shibamanga.com
�
Violet Scans+eu.kanade.tachiyomi.extension.en.shojoscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.shojoscans-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shojoscans.png"1.4(#21.4.358B5���Μ���}Violet Scansen"https://violetscans.org
�
Siren Scans+eu.kanade.tachiyomi.extension.en.sirenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sirenscans-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sirenscans.png"1.4(21.4.208B3���񲡞�PSiren Scansen"https://sirenscans.com
�
	Sky Manga)eu.kanade.tachiyomi.extension.en.skymanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.skymanga-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.skymanga.png"1.4(!21.4.338B0��������-	Sky Mangaen"https://skymanga.work
�
Sleepy Translations3eu.kanade.tachiyomi.extension.en.sleepytranslations�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sleepytranslations-v1.4.52.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sleepytranslations.png"1.4(421.4.528BC�����OSleepy Translationsen"https://sleepytranslations.com
�
Solar and Sundry/eu.kanade.tachiyomi.extension.en.solarandsundry�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.solarandsundry-v1.4.2.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.solarandsundry.png"1.4(21.4.28B9�欮�ٹ�dSolar and Sundryen"https://sas-api.fly.dev
�
Spmanhwa)eu.kanade.tachiyomi.extension.en.spmanhwa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.spmanhwa-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spmanhwa.png"1.4(321.4.518B1�ᦼ���ASpmanhwaen"https://spmanhwa.online
�
SpyFakku)eu.kanade.tachiyomi.extension.en.spyfakku�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.spyfakku-v1.4.15.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spyfakku.png"1.4(21.4.158B,��ܰ��ŉVSpyFakkuen"https://hentalk.pw
�

StoneScape+eu.kanade.tachiyomi.extension.en.stonescape�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.stonescape-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.stonescape.png"1.4(121.4.498B2����탐�R
StoneScapeen"https://stonescape.xyz
�
Sunshine Butterfly Scans7eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sunshinebutterflyscans-v1.4.39.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans.png"1.4('21.4.398B;�䟰����Sunshine Butterfly Scansen"https://wings.sbs
�

SUPER MEGA*eu.kanade.tachiyomi.extension.en.supermega�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.supermega-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.supermega.png"1.4(21.4.48B;��Ρݽ��m
SUPER MEGAen"https://www.supermegacomics.com
�

Genz Toons+eu.kanade.tachiyomi.extension.en.suryascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.suryascans-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.suryascans.png"1.4(521.4.538B1��ǹ����
Genz Toonsen"https://genztoons.org
�
Swords Comic,eu.kanade.tachiyomi.extension.en.swordscomic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.swordscomic-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.swordscomic.png"1.4(21.4.58B5����ײ��8Swords Comicen"https://swordscomic.com
�
Tapas)eu.kanade.tachiyomi.extension.en.tapastic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tapastic-v1.4.24.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tapastic.png"1.4(21.4.248B'��ͣ�ӛ�MTapasen"https://tapas.io
�
	TCB Scans)eu.kanade.tachiyomi.extension.en.tcbscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tcbscans-v1.4.12.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscans.png"1.4(21.4.128B:�������	TCB Scansen"https://tcbonepiecechapters.com
�
TCB Scans (Unoriginal)3eu.kanade.tachiyomi.extension.en.tcbscansunoriginal�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tcbscansunoriginal-v1.4.32.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscansunoriginal.png"1.4( 21.4.328BKΓц����*TCB Scans (Unoriginal)en"#https://tcbscanonepiecechapters.com
�
Team Shadowi,eu.kanade.tachiyomi.extension.en.teamshadowi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.teamshadowi-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.teamshadowi.png"1.4(21.4.18B:������´Team Shadowien"https://www.team-shadowi.com
�
Temple Scan+eu.kanade.tachiyomi.extension.en.templescan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.templescan-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.templescan.png"1.4(121.4.498B4������:Temple Scanen"https://templetoons.com
�
	The Blank)eu.kanade.tachiyomi.extension.en.theblank�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.theblank-v1.4.56.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theblank.png"1.4(821.4.568B/ϳ����פh	The Blanken"https://theblank.net
�
The Duck Webcomics1eu.kanade.tachiyomi.extension.en.theduckwebcomics�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.theduckwebcomics-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theduckwebcomics.png"1.4(21.4.38BD�����JThe Duck Webcomicsen" https://www.theduckwebcomics.com
�
The Property of Hate2eu.kanade.tachiyomi.extension.en.thepropertyofhate�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.thepropertyofhate-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.thepropertyofhate.png"1.4(21.4.58B>����͞�eThe Property of Hateen"https://jolleycomics.com
�
TimelessToons.eu.kanade.tachiyomi.extension.en.timelesstoons�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.timelesstoons-v1.4.20.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.timelesstoons.png"1.4(21.4.208B8�����׫�}TimelessToonsen"https://timelesstoons.org
�

TodayManga+eu.kanade.tachiyomi.extension.en.todaymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.todaymanga-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.todaymanga.png"1.4(21.4.38B2���ˋ���
TodayMangaen"https://todaymanga.com
�
Toon18'eu.kanade.tachiyomi.extension.en.toon18�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toon18-v1.4.51.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toon18.png"1.4(321.4.518B)��������uToon18en"https://toon18.to
�
ToonGod(eu.kanade.tachiyomi.extension.en.toongod�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toongod-v1.4.56.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toongod.png"1.4(821.4.568B0����ʚ��ToonGoden"https://www.toongod.org
�
Toonily(eu.kanade.tachiyomi.extension.en.toonily�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonily-v1.4.65.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonily.png"1.4(A21.4.658B,��˾��HToonilyen"https://toonily.com
�

Toonily.me*eu.kanade.tachiyomi.extension.en.toonilyme�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonilyme-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonilyme.png"1.4(21.4.248B.Ȣ������
Toonily.meen"https://toonily.me
�
	TooniTube*eu.kanade.tachiyomi.extension.en.toonitube�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonitube-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonitube.png"1.4(21.4.248B0���ú�q	TooniTubeen"https://toonitube.com
�
Toonizy(eu.kanade.tachiyomi.extension.en.toonizy�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonizy-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonizy.png"1.4(321.4.518B,�݂۫�KToonizyen"https://toonizy.com
�

Top Manhua*eu.kanade.tachiyomi.extension.en.topmanhua�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhua-v1.4.58.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhua.png"1.4(:21.4.588B0��������
Top Manhuaen"https://mangatop.org
�
TopManhua.fan-eu.kanade.tachiyomi.extension.en.topmanhuafan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhuafan-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuafan.png"1.4(321.4.518B8��������WTopManhua.fanen"https://www.topmanhua.fan
�
TopManhua.net-eu.kanade.tachiyomi.extension.en.topmanhuanet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhuanet-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuanet.png"1.4(321.4.518B4Ѧ䬒׍�YTopManhua.neten"https://topmanhua.net
�
TritiniaScans.eu.kanade.tachiyomi.extension.en.tritiniascans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tritiniascans-v1.4.55.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tritiniascans.png"1.4(721.4.558B3��砫���STritiniaScansen"https://tritinia.org
�
Utoon&eu.kanade.tachiyomi.extension.en.utoon�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.utoon-v1.4.56.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.utoon.png"1.4(821.4.568B(��ʑ����2Utoonen"https://utoon.net
�
Valir Scans+eu.kanade.tachiyomi.extension.en.valirscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.valirscans-v1.4.22.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.valirscans.png"1.4(21.4.228B3�������uValir Scansen"https://valirscans.org
�
Vanilla Scans-eu.kanade.tachiyomi.extension.en.vanillascans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vanillascans-v1.4.23.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vanillascans.png"1.4(21.4.238B7���Ɵî�Vanilla Scansen"https://vanillascans.org
�
vgperson)eu.kanade.tachiyomi.extension.en.vgperson�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vgperson-v1.4.7.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vgperson.png"1.4(21.4.78BD���Ǿ�yvgpersonen"*https://vgperson.com/other/mangaviewer.php
�
VIZ.eu.kanade.tachiyomi.extension.en.vizshonenjump�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vizshonenjump-v1.4.25.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vizshonenjump.png"1.4(21.4.258B4ô������%VIZ Shonen Jumpen"https://www.viz.comB.�´��)	VIZ Mangaen"https://www.viz.com
�
Voyce.Me(eu.kanade.tachiyomi.extension.en.voyceme�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.voyceme-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.voyceme.png"1.4(21.4.68B-�Ԉ�����BVoyceMeen"https://www.voyce.me
�
	VyvyManga*eu.kanade.tachiyomi.extension.en.vyvymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vyvymanga-v1.4.40.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymanga.png"1.4((21.4.408B.٣֐Ӕ��`	VyvyMangaen"https://vymanga.net
�
VyvyManga.org-eu.kanade.tachiyomi.extension.en.vyvymangaorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vyvymangaorg-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymangaorg.png"1.4(321.4.518B4㹕�����!VyvyManga.orgen"https://vyvymanga.org
�
War For Rayuba-eu.kanade.tachiyomi.extension.en.warforrayuba�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.warforrayuba-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.warforrayuba.png"1.4(21.4.38BE��볱��War For Rayubaen"%https://xrabohrok.github.io/WarMap/#/
�

KokoMangas,eu.kanade.tachiyomi.extension.en.wearehunger�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.wearehunger-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wearehunger.png"1.4(521.4.538B1���磷�h
KokoMangasen"https://kokomangas.com
�
	Webcomics*eu.kanade.tachiyomi.extension.en.webcomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webcomics-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webcomics.png"1.4(
21.4.108B3��������h	Webcomicsen"https://webcomicsapp.com
�
Webdex Scans,eu.kanade.tachiyomi.extension.en.webdexscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webdexscans-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webdexscans.png"1.4(421.4.528B5��������wWebdex Scansen"https://webdexscans.com
�
WebNovel)eu.kanade.tachiyomi.extension.en.webnovel�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webnovel-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webnovel.png"1.4(21.4.138B2�������8WebNovelen"https://www.webnovel.com
�
WebtoonScan,eu.kanade.tachiyomi.extension.en.webtoonscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webtoonscan-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonscan.png"1.4(321.4.518B4я������*WebtoonScanen"https://webtoonscan.com
�

WebtoonXYZ+eu.kanade.tachiyomi.extension.en.webtoonxyz�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webtoonxyz-v1.4.55.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonxyz.png"1.4(721.4.558B3�������]
WebtoonXYZen"https://www.webtoon.xyz
�
Weeb Central,eu.kanade.tachiyomi.extension.en.weebcentral�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.weebcentral-v1.4.22.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.weebcentral.png"1.4(21.4.228B5ú�̬ӹ�Weeb Centralen"https://weebcentral.com
�
Whale Manga+eu.kanade.tachiyomi.extension.en.whalemanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.whalemanga-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.whalemanga.png"1.4(321.4.518B2ᰎ�ՠ��N
WhaleMangaen"https://whalemanga.com
�

WitchScans+eu.kanade.tachiyomi.extension.en.witchscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.witchscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.witchscans.png"1.4( 21.4.328B2֥��뤟�v
WitchScansen"https://witchscans.com
�
WoopRead)eu.kanade.tachiyomi.extension.en.woopread�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.woopread-v1.4.52.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.woopread.png"1.4(421.4.528B.��㡓���{WoopReaden"https://woopread.com
�
Writer Scans,eu.kanade.tachiyomi.extension.en.writerscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.writerscans-v1.4.20.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.writerscans.png"1.4(21.4.208B5��ҳ����Writer Scansen"https://writerscans.com
�

WuxiaWorld+eu.kanade.tachiyomi.extension.en.wuxiaworld�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.wuxiaworld-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wuxiaworld.png"1.4(421.4.528B3���۠���Z
WuxiaWorlden"https://wuxiaworld.site
�
XlecX&eu.kanade.tachiyomi.extension.en.xlecx�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xlecx-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xlecx.png"1.4(21.4.18B(ǆ�����3XlecXen"https://xlecx.one
�
XoManga(eu.kanade.tachiyomi.extension.en.xomanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xomanga-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xomanga.png"1.4(21.4.18B1��ﳽ�ؙEXoMangaen"https://www.xomanga.site
�
XOXO Comics+eu.kanade.tachiyomi.extension.en.xoxocomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xoxocomics-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xoxocomics.png"1.4(21.4.138B2�����Χ�!XOXO Comicsen"https://xoxocomic.com
�
Xscans'eu.kanade.tachiyomi.extension.en.xscans�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xscans-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xscans.png"1.4(21.4.18B+�҃���eXscansen"https://xscans.site
�
YakshaComics-eu.kanade.tachiyomi.extension.en.yakshacomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yakshacomics-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yakshacomics.png"1.4(521.4.538B6��������CYakshaComicsen"https://yakshacomics.com
�
YaoiHot(eu.kanade.tachiyomi.extension.en.yaoihot�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoihot-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihot.png"1.4(21.4.18B,��������&YaoiHoten"https://yaoihot.com
�
Yaoihub(eu.kanade.tachiyomi.extension.en.yaoihub�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoihub-v1.4.53.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihub.png"1.4(521.4.538B,��ʸ��]Yaoihuben"https://yaoihub.net
�
YaoiScan)eu.kanade.tachiyomi.extension.en.yaoiscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoiscan-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoiscan.png"1.4(321.4.518B.��Ӹ����=YaoiScanen"https://yaoiscan.com
�
YaoiToon)eu.kanade.tachiyomi.extension.en.yaoitoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoitoon-v1.4.48.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoitoon.png"1.4(021.4.488B.謈�����QYaoiToonen"https://yaoitoon.net
�
Yorai&eu.kanade.tachiyomi.extension.en.yorai�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yorai-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yorai.png"1.4(21.4.28B'����Ϩ�"Yoraien"https://yorai.io
�
	Zazamanga*eu.kanade.tachiyomi.extension.en.zazamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zazamanga-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zazamanga.png"1.4(421.4.528B4���ּװ�	Zazamangaen"https://www.zazamanga.com
�
ZinChanManga-eu.kanade.tachiyomi.extension.en.zinchanmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinchanmanga-v1.4.54.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmanga.png"1.4(621.4.548B7�ɿ�����ZinChanMangaen"https://zinchangmanga.net
�
ZinChanManga.com0eu.kanade.tachiyomi.extension.en.zinchanmangacom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinchanmangacom-v1.4.54.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmangacom.png"1.4(621.4.548B;՝������uZinChanManga.comen"https://zinchangmanga.net
�
Zinmanga)eu.kanade.tachiyomi.extension.en.zinmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinmanga-v1.4.54.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanga.png"1.4(621.4.548B.�����ʐSZinmangaen"https://mangazin.org
�
Zinmanga.net,eu.kanade.tachiyomi.extension.en.zinmanganet�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinmanganet-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanganet.png"1.4(321.4.518B2���⢸��Zinmanga.neten"https://zinmanga.net
�
	BlackToon*eu.kanade.tachiyomi.extension.ko.blacktoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.blacktoon-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.blacktoon.png"1.4(21.4.18B/�Ϫ�ۃ�b	블랙툰ko"https://blacktoon.me
�
Manatoki)eu.kanade.tachiyomi.extension.ko.manatoki�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.manatoki-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.manatoki.png"1.4(21.4.28B1���Ӈչ�1Manatokiko"https://manatoki552.net
�
Naver Comic+eu.kanade.tachiyomi.extension.ko.navercomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.navercomic-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.navercomic.png"1.4(21.4.78B6���ɢ�Naver Webtoonko"https://comic.naver.comBE��������7Naver Webtoon Best Challengeko"https://comic.naver.comB@����ۣ>Naver Webtoon Challengeko"https://comic.naver.com
�
RawDEX'eu.kanade.tachiyomi.extension.ko.rawdex�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.rawdex-v1.4.54.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.rawdex.png"1.4(621.4.548B*���񐾿�nRawDEXko"https://rawdex.net
�
11toon'eu.kanade.tachiyomi.extension.ko.toon11�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.toon11-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.toon11.png"1.4(21.4.28B.��������z11toonko"https://www.11toon.com
�
Toonkor(eu.kanade.tachiyomi.extension.ko.toonkor�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.toonkor-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.toonkor.png"1.4(21.4.68B,��������[Toonkorko"https://tkor114.com
�
Wolf.com+eu.kanade.tachiyomi.extension.ko.wolfdotcom�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.wolfdotcom-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.wolfdotcom.png"1.4(21.4.38B:��������M늑대닷컴 - 웹툰ko"https://wfwf476.comB=��Ь����b늑대닷컴 - 만화책ko"https://wfwf476.comB=�����π�:늑대닷컴 - 포토툰ko"https://wfwf476.com
�
CManga'eu.kanade.tachiyomi.extension.vi.cmanga�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.cmanga-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.cmanga.png"1.4(21.4.38B-ٻ�љ���RCMangavi"https://cmangax17.com
�

Cuu Truyen*eu.kanade.tachiyomi.extension.vi.cuutruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.cuutruyen-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.cuutruyen.png"1.4(21.4.18B1�����ٚ�o
Cuu Truyenvi"https://cuutruyen.net
�
CuuTruyen (unoriginal)-eu.kanade.tachiyomi.extension.vi.cuutruyenmoe�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.cuutruyenmoe-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.cuutruyenmoe.png"1.4(21.4.28B=��������7CuuTruyen (unoriginal)vi"https://cuutruyen.moe
�

DamCoNuong+eu.kanade.tachiyomi.extension.vi.damconuong�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.damconuong-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.damconuong.png"1.4(21.4.68B2��躓���%
DamCoNuongvi"https://damconuong.mom
�
	DaoMeoDen*eu.kanade.tachiyomi.extension.vi.daomeoden�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.daomeoden-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.daomeoden.png"1.4(21.4.28B0��������2	DaoMeoDenvi"https://daomeoden.net
�
DocTruyen3Q,eu.kanade.tachiyomi.extension.vi.doctruyen3q�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.doctruyen3q-v1.4.34.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.doctruyen3q.png"1.4("21.4.348B8������UDocTruyen3Qvi"https://doctruyen3qhub1.com
�
DocTruyen5s,eu.kanade.tachiyomi.extension.vi.doctruyen5s�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.doctruyen5s-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.doctruyen5s.png"1.4(	21.4.98B0�����iDocTruyen5svi"https://manga.io.vn
�
Dua Leo Truyen-eu.kanade.tachiyomi.extension.vi.dualeotruyen�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.dualeotruyen-v1.4.22.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.dualeotruyen.png"1.4(21.4.228B=�њ�ł��Dưa Leo Truyệnvi"https://dualeotruyenpt.com
�
FastScan)eu.kanade.tachiyomi.extension.vi.fastscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.fastscan-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.fastscan.png"1.4(21.4.38B.��������<FastScanvi"https://fastscan.org
�
Goc Truyen Tranh/eu.kanade.tachiyomi.extension.vi.goctruyentranh�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.goctruyentranh-v1.4.12.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.goctruyentranh.png"1.4(21.4.128B:�Ո����qGocTruyenTranhvi"https://goctruyentranh.com
�
Goc Truyen Tranh Vui2eu.kanade.tachiyomi.extension.vi.goctruyentranhvui�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.goctruyentranhvui-v1.4.15.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.goctruyentranhvui.png"1.4(21.4.158BEƲ��֣��'Goc Truyen Tranh Vuivi"https://goctruyentranhvui30.com
�
HentaiCB+eu.kanade.tachiyomi.extension.vi.hentaicube�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaicube-v1.4.81.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaicube.png"1.4(Q21.4.818B,ƶ���҉�HentaiCBvi"https://2tencb.pro
�
HentaiVNBond-eu.kanade.tachiyomi.extension.vi.hentaivnbond�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaivnbond-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaivnbond.png"1.4(421.4.528B3��ڢ����zHentaiVNBondvi"https://hentaivn.bond
�
HentaiVN.plus-eu.kanade.tachiyomi.extension.vi.hentaivnplus�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaivnplus-v1.4.69.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaivnplus.png"1.4(E21.4.698B4�͔�£��aHentaiVN.plusvi"https://hentaivn.show
�
	HentaiVNx*eu.kanade.tachiyomi.extension.vi.hentaivnx�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaivnx-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaivnx.png"1.4(21.4.58B4����烎I	HentaiVNxvi"https://www.hentaivnx.com
�
	KamiComic*eu.kanade.tachiyomi.extension.vi.kamicomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.kamicomic-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.kamicomic.png"1.4(21.4.48B/��͓�θ�C	KamiComicvi"https://kamicomi.com
�
KiraKira)eu.kanade.tachiyomi.extension.vi.kirakira�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.kirakira-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.kirakira.png"1.4(21.4.28B0���ڄ҉]KiraKiravi"https://truyenkira.com
�
	LoppyToon*eu.kanade.tachiyomi.extension.vi.loppytoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.loppytoon-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.loppytoon.png"1.4(21.4.58B0���͉���[	LoppyToonvi"https://loppytoon.com
�

LuotTruyen+eu.kanade.tachiyomi.extension.vi.luottruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.luottruyen-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.luottruyen.png"1.4(21.4.48B4�����錅[
LuotTruyenvi"https://luottruyen10.com
�

LuvEvaLand+eu.kanade.tachiyomi.extension.vi.luvevaland�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.luvevaland-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.luvevaland.png"1.4(21.4.28B3�������E
LuvEvaLandvi"https://luvevalands2.co
�
LXManga)eu.kanade.tachiyomi.extension.vi.lxhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.lxhentai-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.lxhentai.png"1.4( 21.4.328B.�Ύ���ǒZLXMangavi"https://lxmanga.space
�
MatoDex(eu.kanade.tachiyomi.extension.vi.matodex�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.matodex-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.matodex.png"1.4(21.4.18B3��݂����MatoDexvi"https://mato.suicaodex.com
�
MeDamTruyen,eu.kanade.tachiyomi.extension.vi.medamtruyen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.medamtruyen-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.medamtruyen.png"1.4(21.4.78B5����ϱ��MeDamTruyenvi"https://saytongtaii.site
�
MeHentai)eu.kanade.tachiyomi.extension.vi.mehentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mehentai-v1.4.11.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mehentai.png"1.4(21.4.118B/�㣦����MeHentaivi"https://mehentai.blog
�
MeoSua'eu.kanade.tachiyomi.extension.vi.meosua�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.meosua-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.meosua.png"1.4(21.4.28B*Џ�ʎ���MeoSuavi"https://meosua.com
�
MiMi%eu.kanade.tachiyomi.extension.vi.mimi�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mimi-v1.4.6.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mimi.png"1.4(21.4.68B)񘪲ռ��#MiMivi"https://mimimoe.moe
�

MiMiHentai+eu.kanade.tachiyomi.extension.vi.mimihentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mimihentai-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mimihentai.png"1.4(21.4.68B2�������o
MiMiHentaivi"https://mimihentai.net
�

MinoTruyen+eu.kanade.tachiyomi.extension.vi.minotruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.minotruyen-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.minotruyen.png"1.4(21.4.38B:ޞ���΋�MinoTruyen Mangavi"https://minotruyenv5.xyzB;ޥ������4MinoTruyen Comicsvi"https://minotruyenv5.xyzB;���сɲQMinoTruyen Hentaivi"https://minotruyenv5.xyz
�
	MoeTruyen*eu.kanade.tachiyomi.extension.vi.moetruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.moetruyen-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.moetruyen.png"1.4(21.4.68B0����ی��x	MoeTruyenvi"https://moetruyen.net
�

MoonTruyen+eu.kanade.tachiyomi.extension.vi.moontruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.moontruyen-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.moontruyen.png"1.4(21.4.28B2���ŕ���]
MoonTruyenvi"https://moontruyen.com
�
	MunTruyen*eu.kanade.tachiyomi.extension.vi.muntruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.muntruyen-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.muntruyen.png"1.4(21.4.38B2�ޛ����t	MunTruyenvi"https://moonnovel.store
�
NetTruyen0209.eu.kanade.tachiyomi.extension.vi.nettruyen0209�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyen0209-v1.4.11.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyen0209.png"1.4(21.4.118B7��彍���hNetTruyen0209vi"https://nettruyen12s.com
�
NetTruyenCO (unoriginal),eu.kanade.tachiyomi.extension.vi.nettruyenco�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenco-v1.4.16.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenco.png"1.4(21.4.168BA�������1NetTruyenCO (unoriginal)vi"https://nettruyenar.com
�
NetTruyenS (unoriginal)+eu.kanade.tachiyomi.extension.vi.nettruyens�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyens-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyens.png"1.4(21.4.28BA��ࣂ��TNetTruyenS (unoriginal)vi"https://nettruyen10s.com
�
NetTruyenViet (unoriginal).eu.kanade.tachiyomi.extension.vi.nettruyenviet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenviet-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenviet.png"1.4(21.4.38BG��ћ쇀�7NetTruyenViet (unoriginal)vi"https://nettruyenviet10.com
�
NetTruyenX (unoriginal)+eu.kanade.tachiyomi.extension.vi.nettruyenx�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenx-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenx.png"1.4(	21.4.98B?��������+NetTruyenX (unoriginal)vi"https://nettruyenx.net
�

NhatTruyen+eu.kanade.tachiyomi.extension.vi.nhattruyen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nhattruyen-v1.4.29.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nhattruyen.png"1.4(21.4.298B4�Ԃ�Ȼ�_
NhatTruyenvi"https://nhattruyenqq.com
�
NhentaiClub,eu.kanade.tachiyomi.extension.vi.nhentaiclub�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nhentaiclub-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nhentaiclub.png"1.4(21.4.28B6��ȟ���~NhentaiClubvi"https://nhentaiclub.space
�
Otakusic)eu.kanade.tachiyomi.extension.vi.otakusic�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.otakusic-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.otakusic.png"1.4(21.4.28B.��ςĭ��AOtakusicvi"https://otakusic.com
�
OTruyen(eu.kanade.tachiyomi.extension.vi.otruyen�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.otruyen-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.otruyen.png"1.4(21.4.28B+���Ӑ�ŀpOTruyenvi"https://otruyen.cc
�
Panomic(eu.kanade.tachiyomi.extension.vi.panomic�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.panomic-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.panomic.png"1.4(21.4.38B.���Ԯ﬘KPanomicvi"https://panomic1.info
�
	SayHentai*eu.kanade.tachiyomi.extension.vi.sayhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.sayhentai-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.sayhentai.png"1.4(21.4.238B/��������<	SayHentaivi"https://sayhentai.cx
�
Seikowo(eu.kanade.tachiyomi.extension.vi.seikowo�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.seikowo-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.seikowo.png"1.4(21.4.28B9��������*Seikowovi" https://seikowo-app.blogspot.com
�
SoaiCaComic,eu.kanade.tachiyomi.extension.vi.soaicacomic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.soaicacomic-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.soaicacomic.png"1.4(21.4.38B5���ջ�ŉSoaiCaComicvi"https://soaicacomic2.top
�
Team Lanh Lung-eu.kanade.tachiyomi.extension.vi.teamlanhlung�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.teamlanhlung-v1.4.33.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.teamlanhlung.png"1.4(!21.4.338B:��������Team Lạnh Lùngvi"https://icecoldcore.com
�
ThienThaiTruyen0eu.kanade.tachiyomi.extension.vi.thienthaitruyen�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.thienthaitruyen-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.thienthaitruyen.png"1.4(21.4.48B>����׸�=ThienThaiTruyenvi"https://thienthaitruyen10.com
�

Top Truyen*eu.kanade.tachiyomi.extension.vi.toptruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.toptruyen-v1.4.37.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.toptruyen.png"1.4(%21.4.378B:�ڱ����
Top Truyenvi"https://www.toptruyenzone4.com
�
Tranh18(eu.kanade.tachiyomi.extension.vi.tranh18�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tranh18-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tranh18.png"1.4(21.4.58B+���˿���Tranh18vi"https://tranh18.cc
�
Truyen18)eu.kanade.tachiyomi.extension.vi.truyen18�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyen18-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyen18.png"1.4(21.4.28B-���˟鳵gTruyen18vi"https://truyen18.co
�
	FoxTruyen)eu.kanade.tachiyomi.extension.vi.truyengg�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyengg-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyengg.png"1.4(21.4.138B1��݌��؟	FoxTruyenvi"https://foxtruyen2.com
�

TruyenGGVN+eu.kanade.tachiyomi.extension.vi.truyenggvn�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenggvn-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenggvn.png"1.4(21.4.18B2��㑪�ܜ4
TruyenGGVNvi"https://truyenggvn.com
�
Truyen Hentai 18+/eu.kanade.tachiyomi.extension.vi.truyenhentai18�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentai18-v1.4.11.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentai18.png"1.4(21.4.118B?�̹�Ƭ��YTruyện Hentai 18+vi"https://truyenhentai18.net
�
TruyenHentaivn/eu.kanade.tachiyomi.extension.vi.truyenhentaivn�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentaivn-v1.4.4.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentaivn.png"1.4(21.4.48B<�������"TruyenHentaivnvi"https://truyenhentaivn.space
�
TruyenHentaiz.eu.kanade.tachiyomi.extension.vi.truyenhentaiz�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentaiz-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentaiz.png"1.4(21.4.28B8��կƲcTruyenHentaizvi"https://truyenhentaiz.net
�
TruyenMM)eu.kanade.tachiyomi.extension.vi.truyenmm�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenmm-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenmm.png"1.4(21.4.28B2��Ѻ���ATruyenMMvi"https://truyenmmhayr.com
�
TruyenQQ)eu.kanade.tachiyomi.extension.vi.truyenqq�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenqq-v1.4.24.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenqq.png"1.4(21.4.248B0�������#TruyenQQvi"https://truyenqqko.com
�
TruyenQQ.com.vn.eu.kanade.tachiyomi.extension.vi.truyenqqcomvn�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenqqcomvn-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenqqcomvn.png"1.4(21.4.18B8�������,TruyenQQ.com.vnvi"https://truyenqq.com.vn
�
Truyen tranh dam my1eu.kanade.tachiyomi.extension.vi.truyentranhdammy�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentranhdammy-v1.4.54.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentranhdammy.png"1.4(621.4.548BH��ֶ����4Truyện tranh đam mỹvi"https://truyentranhdammyy.site
�
TruyenTuoiTho.eu.kanade.tachiyomi.extension.vi.truyentuoitho�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentuoitho-v1.4.54.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentuoitho.png"1.4(621.4.548B;��Ϗ����TruyenTuoiThovi"https://truyentuoitho.online
�
	TruyenTVN*eu.kanade.tachiyomi.extension.vi.truyentvn�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentvn-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentvn.png"1.4(21.4.28B0֋������.	TruyenTVNvi"https://truyentvn.net
�
TruyenVN)eu.kanade.tachiyomi.extension.vi.truyenvn�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenvn-v1.4.68.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenvn.png"1.4(D21.4.688B.��褥���OTruyenVNvi"https://truyenvn.sbs
�
	TuiTruyen*eu.kanade.tachiyomi.extension.vi.tuitruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tuitruyen-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tuitruyen.png"1.4(21.4.38B0��������=	TuiTruyenvi"https://tuitruyen.top
�
TuSachXinhXinh/eu.kanade.tachiyomi.extension.vi.tusachxinhxinh�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tusachxinhxinh-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tusachxinhxinh.png"1.4(21.4.38B?��������{TuSachXinhXinhvi"https://tusachxinhxinh12.online
�
	UmeTruyen*eu.kanade.tachiyomi.extension.vi.umetruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.umetruyen-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.umetruyen.png"1.4(	21.4.98B1�ⷌ�ډ�"	UmeTruyenvi"https://umetruyenz.org
�
ViHentai)eu.kanade.tachiyomi.extension.vi.vihentai�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vihentai-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vihentai.png"1.4(21.4.48B/歿�����7ViHentaivi"https://vi-hentai.moe
�

VinaHentai+eu.kanade.tachiyomi.extension.vi.vinahentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vinahentai-v1.4.10.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vinahentai.png"1.4(
21.4.108B4߱��ψ��?
VinaHentaivi"https://vinahentai.cloud
�

YuriGarden+eu.kanade.tachiyomi.extension.vi.yurigarden�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.yurigarden-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.yurigarden.png"1.4(	21.4.98B2���ʥ���
YuriGardenvi"https://yurigarden.moe
�
YuriNeko)eu.kanade.tachiyomi.extension.vi.yurineko�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.yurineko-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.yurineko.png"1.4(21.4.68B/Ғ����=YuriNekovi"https://yurinekoz.com
�
	ZetTruyen*eu.kanade.tachiyomi.extension.vi.zettruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.zettruyen-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.zettruyen.png"1.4(
21.4.108B4�ڎ���γ	ZetTruyenvi"https://www.zettruyen.fit